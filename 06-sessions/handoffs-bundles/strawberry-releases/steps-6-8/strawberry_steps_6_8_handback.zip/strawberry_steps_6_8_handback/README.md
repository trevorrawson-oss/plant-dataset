# Strawberry Steps 6-8 handback (claude.ai authoring lane -> Claude Code)

**Session:** `strawberry_steps_6_8` | **Date:** 2026-06-19 | **Anchor 13** (the first/only `berries_herbaceous` crop).
**Arc leg:** the bulk dual-register prose + the 6 empty compound blocks -- the last big authoring leg before cert.

## Preflight (already done in-lane)
- LATEST.txt full-file SHA: `ec0bf9d0...` (the patch base).
- Slice integrity crop SHA: `f42aaf47...` -- confirmed against SLICE_INTEGRITY.md (faithful to canonical). Authored against the slice.

## What's here
- **`dataset_update/`** -- the deliverable change:
  - `strawberry_6_8_patch.json` (76 ops, handoff format v1.0, drift-guarded)
  - `SOURCE_MINT_FLAG.md` (mint `uc_anr_8256` at apply)
  - `PATCH_NOTE.txt` (base SHA, apply command, expected gate movement)
- **`1_for_project_knowledge/`** -- nothing new this session (no methodology/schema/checklist change); see README.txt.
- **`2_for_next_chat/`** -- `STATE_HISTORY_snippet.md` (append to STATE_HISTORY.md), regenerated `CURRENT_STATE.md` (full, not a delta), `open_findings.md`.
- **`3_for_your_records/`** -- `source_ledger.md` (the T1 fact base), `author_6_8.py` (the authoring script that emits the patch + self-checks).

## Claude Code: apply sequence
1. Preflight `sha256(crops_data_final.json) == ec0bf9d0...`.
2. `python3 tools/apply_patch.py dataset_update/strawberry_6_8_patch.json --base crops_data_final.json --out crops_data_final.scratch.json`
3. Mint `uc_anr_8256` (SOURCE_MINT_FLAG.md).
4. Re-run: `register_fill_gate strawberry` (-> 0), `register_completeness_gate`, `whole_crop_gate strawberry` (PASS incl. D9/A10 + A11 fill branches).
5. Verify stage-id references resolve (fertilizer.stage_id / schedule_by_stage[].stage_id / notifications.stage -> growth_stages ids).
6. Confirm renderer accepts `stage`-type notification triggers with null calendar offsets (open question in open_findings.md).
7. Compute authoritative post-apply crop SHA on the FULL file; update LATEST.txt; promote (protocol #6).

## After this: Step 5 (verification + the 2 deferred boundary/hawaii decisions) -> Step 9 (sweep) -> Step 11 cert flip.
