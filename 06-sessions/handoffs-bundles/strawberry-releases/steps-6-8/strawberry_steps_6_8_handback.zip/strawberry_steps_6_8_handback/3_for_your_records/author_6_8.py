#!/usr/bin/env python3
"""Strawberry Steps 6-8 authoring -> emits handoff patch (v1.0 format) + STATE_HISTORY snippet.
Block-coherent + anchored. T1 only. American English. degF symbol. No user-facing '--'.
Author against the SLICE (crop SHA f42aaf47...); Claude Code applies against full file (ec0bf9d0...).
"""
import json, hashlib, copy

SLICE = "/mnt/user-data/uploads/strawberry_slice.json"
FULL_BASE_SHA = "ec0bf9d0529eca6d5352d7eb9fa005f3182750b09e0c4288b833ee44fc2caee2"  # LATEST.txt (full file)
CROP_SHA = "f42aaf47aeebd78575bd160f8429aeb5bd1fbcae52be02e0f75ac00c15c92807"        # slice integrity

crop = json.load(open(SLICE))
P = "$.crops[?(@.slug=='strawberry')]"

# ---- source URL leaves (per-source anchoring_urls), all verified 2026-06-18 ----
V = "2026-06-18"
URL = {
  "osu_ext": "https://extension.oregonstate.edu/catalog/ec-1307-growing-strawberries-your-home-garden",
  "umn_ext": "https://extension.umn.edu/fruit/growing-strawberries-home-garden",
  "umd_ext": "https://extension.umd.edu/resource/growing-strawberries-home-garden",
  "usu_ext": "https://extension.usu.edu/yardandgarden/research/strawberries-in-the-garden",
  "uc_anr_8256": "https://anrcatalog.ucanr.edu/pdf/8256.pdf",
}
def au(*ids):
    return {i: {"url": URL[i], "verified": V} for i in ids}

patches = []
def add(json_path, value):
    patches.append({"op": "add", "json_path": f"{P}.{json_path}", "value": value})
def repl(json_path, frm, value):
    patches.append({"op": "replace", "json_path": f"{P}.{json_path}", "from": frm, "value": value})

# =====================================================================================
# GROWTH_STAGES FIRST (mints stage ids referenced by fertilizer.stage_id + schedule_by_stage + notifications)
# Perennial arc ids: plant -> establishment -> runner -> bloom -> fruit_set -> harvest -> renovation -> dormancy
# peach shape (13 keys): id, name, day_range_from_sow(null OK), year_phase, timing_*, what_to_look_for_*,
#   user_action_*, log_prompt_*, audience
# =====================================================================================
def stage(id_, name, year_phase, timing_s, timing_b, look_s, look_b, a3_s, a3_b, a4_s, a4_b, a5_s=None, a5_b=None, audience="core"):
    # Stages authored with 5 content pairs: timing, look, ACTION-A, ACTION-B(extra), LOG.
    # The peach output schema has timing/what_to_look_for/user_action/log_prompt.
    # Fold the two action-style pairs into one user_action; the last pair is the log_prompt.
    if a5_s is not None:
        user_s, user_b, log_s, log_b = a3_s, a3_b, a4_s, a4_b   # 5-pair form: a3=action, a4=action2, a5=log
        # join the two action segments
        user_s = a3_s + " " + a4_s
        user_b = a3_b + " " + a4_b
        log_s, log_b = a5_s, a5_b
    else:
        user_s, user_b, log_s, log_b = a3_s, a3_b, a4_s, a4_b   # 4-pair form: a3=action, a4=log
    return {
        "id": id_, "name": name, "day_range_from_sow": None, "year_phase": year_phase,
        "timing_seasoned": timing_s, "timing_beginner": timing_b,
        "what_to_look_for_seasoned": look_s, "what_to_look_for_beginner": look_b,
        "user_action_seasoned": user_s, "user_action_beginner": user_b,
        "log_prompt_seasoned": log_s, "log_prompt_beginner": log_b,
        "audience": audience,
    }

growth_stages = [
  stage("plant", "Planting", "year_1_spring",
    "Set dormant bare-root crowns or potted plugs in the planting window, crown midpoint level with the soil surface. In matted rows, space plants about 15 inches apart in rows 3 to 4 feet apart.",
    "Plant your strawberry crowns or small potted plants, setting each so the middle of the crown sits right at soil height. In a wide row, leave about 15 inches between plants.",
    "Newly set plants with the growing tip exposed and roots just below the surface; no top growth yet on bare-root crowns.",
    "A small bud at the top of each crown sitting in the light, with roots tucked just under the soil.",
    "Firm the soil around the roots and water in to settle it. Check that the crown is still at the right depth after watering and adjust if it has sunk or heaved.",
    "Press the soil down around the roots and water. Make sure the little bud on top is not buried and the roots are not poking out.",
    "Planted: variety, type, and number of crowns set, with the date.",
    "Wrote down what you planted and when."),
  stage("establishment", "Establishment", "year_1",
    "The first season after planting. June-bearing plants pour energy into roots, crown, and runners rather than fruit; all flowers are pinned off to build a strong matted row for year two.",
    "The first growing season. The plants are building roots and spreading, not making a real crop yet.",
    "New leaves unfurling from the crown and the first flower stems emerging. On June-bearers these flowers are removed, not kept.",
    "Fresh leaves growing and small flower stalks appearing. On June-bearing plants you pick these flowers off.",
    "Pinch off every flower on June-bearers through the first season so the plant invests in establishment. On day-neutral and everbearing plants, remove flowers only for the first four to six weeks, then allow fruiting.",
    "On June-bearing plants, pinch off all the flowers the first year so the plant grows strong. On day-neutral or everbearing plants, only pick off flowers for the first month or so.",
    "Keep the bed evenly watered and weed-free; strawberries have shallow roots and lose out to weeds quickly.",
    "Water often and pull weeds. The roots are shallow, so weeds crowd them out fast.",
    "Establishment: leaf-out date and, for June-bearers, that flowers are being pinched.",
    "Noted that leaves are growing and, for June-bearers, that you are picking off flowers."),
  stage("runner", "Runner and daughter-plant growth", "year_1_summer",
    "June-bearers send out runners (stolons) bearing daughter plants from early summer. Early runners (rooted before September) are the productive ones; sweep strays back into the row so they root in the bed, not the aisle.",
    "Through summer the plants send out long stems called runners, with baby plants on the ends. These fill in your row.",
    "Above-ground stems arching out from the mother plant with small plantlets that root where they touch soil.",
    "Long stems creeping out sideways with little new plants on them that take root when they reach the ground.",
    "Guide early runners into the row to build the matted bed. In containers or a hill system, remove runners instead, since daughter plants cannot root over a pot edge and only drain the mother.",
    "Let the runners root in your row to fill it in. If you are growing in a pot, snip the runners off, because they cannot root in a pot and just weaken the plant.",
    "Direct early runners into the row before they root in the aisle; remove late runners that will not fruit next year.",
    "Tuck the runners into your row so they root there, not in the path.",
    "Runners: that daughter plants are rooting in the row (or being removed in containers).",
    "Noted that runners are filling in the row, or that you removed them from a pot."),
  stage("bloom", "Bloom", "year_2_spring",
    "On an established bed (year two and later), June-bearing plants flower in mid-spring near the last-frost date. Open blossoms are frost-sensitive, so a late frost during bloom can cut the crop.",
    "In the second year and after, the plants flower in mid-spring. These open flowers can be killed by a late frost.",
    "White five-petaled flowers opening across the bed, with yellow centers that become the fruit.",
    "White flowers with yellow centers opening up. Each one can turn into a berry.",
    "Watch the forecast during bloom. Cover open flowers with row cover in the late afternoon when frost is predicted and remove it the next morning once the danger has passed.",
    "Keep an eye on the weather while the plants flower. If frost is coming, cover the flowers in the evening with a light cloth and take it off in the morning.",
    "If row cover is over the bed, pull it back as bloom opens so bees can reach the flowers and set well-shaped fruit.",
    "If you covered the plants, open them up while they flower so bees can get to them.",
    "Bloom: first-flower date and any frost protection used.",
    "Noted when flowers opened and whether you covered them for frost."),
  stage("fruit_set", "Green fruit and ripening", "year_2_spring",
    "Pollinated flowers form green fruit that swells and colors over roughly four weeks. Fruit is mostly water, so steady moisture through this period drives size and quality.",
    "After the flowers are pollinated, small green berries form and slowly ripen over about four weeks. The berries need steady water now.",
    "Green berries enlarging and beginning to blush red. Well-pollinated fruit is plump and even; poorly pollinated fruit is grooved or pinched.",
    "Green berries getting bigger and starting to turn red. Good berries are plump and even; lumpy ones did not get pollinated well.",
    "Keep moisture steady and even, about 1 to 1.5 inches of water a week, and keep ripening fruit off wet soil to limit gray mold.",
    "Water evenly, about 1 to 1.5 inches a week. Try to keep the ripening berries off wet ground so they do not rot.",
    "Maintain even watering and watch for the first blush of color to time your first picking.",
    "Keep watering and watch for the first berries to turn red.",
    "Fruit set: that green fruit has formed and is beginning to color.",
    "Noted that green berries formed and are starting to ripen."),
  stage("harvest", "Harvest", "year_2_summer",
    "June-bearing strawberries ripen about four weeks after flowering, giving one concentrated flush over roughly four weeks. Pick every one to three days; fruit is sweetest fully red and ripened on the plant.",
    "About four weeks after flowering, the berries ripen all at once over roughly four weeks. Pick every couple of days, and let them turn fully red for the best flavor.",
    "Fully red, fragrant berries that pull free easily. Color deepens after picking, so fruit picked at 75 percent red stores a little longer.",
    "Bright red, sweet-smelling berries that come off easily. If you need them to last longer, pick when they are about three-quarters red.",
    "Harvest in the cool of the morning and refrigerate promptly. If a long rain is forecast, pick fruit that is 75 percent to fully red, since rain dilutes flavor and invites rot.",
    "Pick in the morning when it is cool and get the berries into the fridge soon. If a lot of rain is coming, pick the riper berries first so they do not rot.",
    "Pick ripe fruit every one to three days, checking more often in warm weather; remove any rotting berries to protect the rest.",
    "Pick ripe berries every day or two, more often when it is hot. Toss any moldy ones so they do not spread.",
    "Harvest: first-pick date and a rough running weight if you want to track yield.",
    "Noted when you started picking and how the harvest is going."),
  stage("renovation", "Renovation", "year_2_summer",
    "June-bearing matted rows only. Within one to two weeks of the last picking, mow leaves to about 2 inches above the crowns, rake debris, narrow the row to 10 to 12 inches, then fertilize and irrigate to push fresh growth. Day-neutral and everbearing plants are not renovated.",
    "For June-bearing wide rows only. A week or two after the last berries, mow the old leaves to about 2 inches above the crowns, rake them away, narrow the row, then feed and water. Leave day-neutral and everbearing plants alone.",
    "Tired, spotted foliage after the four-week harvest. After renovation the crowns regrow fresh leaves and new runners within a few weeks.",
    "Worn-out leaves after harvest. Once you cut them back, the plants grow fresh leaves again in a few weeks.",
    "Mow without cutting into the crowns, remove the clippings to reduce next spring's fruit rot, narrow the matted row, and fertilize at the renovation rate to drive flower-bud development for next year.",
    "Cut the leaves but not the crowns, rake the cut leaves away, narrow the row, and feed the plants so they set up next year's crop.",
    "Renovate within one to two weeks of the final harvest; fertilize and water right after to encourage regrowth.",
    "Renovate a week or two after the last berries, then feed and water.",
    "Renovation: the date you mowed and renovated the bed.",
    "Noted the day you cut back and tidied the bed."),
  stage("dormancy", "Dormancy and winter", "year_round_winter",
    "In cold regions the bed goes dormant in late fall. Crowns are injured between about 10 and 20 degrees F at the crown, so a 2 to 3 inch loose straw mulch is applied after the first hard freeze and raked off in early spring. In wet-winter regions, straw over the crowns invites rot and is skipped.",
    "In cold areas the plants go dormant for winter. Cover them with 2 to 3 inches of loose straw after the first hard freeze to protect the crowns, then rake it off in early spring. In mild, rainy areas, skip the straw because it makes the crowns rot.",
    "Plants stop growing and leaves die back where winters are cold. In mild regions the plants may hold some green leaves through winter.",
    "The plants stop growing and the leaves die back in cold places. In mild places they may stay a little green.",
    "Apply straw after plants harden off and the first hard freeze arrives, not earlier, which would smother the crowns. Remove it as growth resumes in spring. Move containers to an unheated garage or sink them to the rim and mulch.",
    "Put straw on after the first hard freeze, not before, or it will smother the plants. Take it off when growth starts in spring. Move pots into an unheated garage or bury them to the rim and cover with mulch.",
    "Mulch cold-region beds for winter and plan to remove it promptly in spring; protect container roots, which freeze harder than in-ground beds.",
    "Cover the bed with straw for winter in cold areas and uncover it in spring. Protect pots, since roots in pots get colder than roots in the ground.",
    "Dormancy: the date you mulched for winter (cold regions).",
    "Noted when you covered the plants for winter."),
]
repl("growth_stages", [], growth_stages)

# =====================================================================================
# FERTILIZER block (register pairs + structured scalars + anchor). Stage-wired to 'renovation'.
# EC1307 numbers: new 0.5-0.8 oz N/10ft split; established June-bearer 0.4-0.6 oz N/10ft at renovation.
# =====================================================================================
repl("fertilizer.frequency", None, "At planting and through the first season for new plantings; for established June-bearing beds, once a year at renovation.")
repl("fertilizer.type", None, "balanced_granular")
repl("fertilizer.timing", None, "renovation")
repl("fertilizer.example_product", None, "16-16-16 balanced fertilizer (or a comparable all-purpose granular)")
repl("fertilizer.notify_days_after", None, None)  # timing is stage-anchored (renovation), not day-offset
repl("fertilizer.stage_id", None, "renovation")
repl("fertilizer.notes_seasoned", None,
  "Strawberry feeding is nitrogen-driven and timed to the planting model. In the first year, apply a total of about 0.5 to 0.8 ounces of actual nitrogen per 10 feet of row, split across the season: a small dose one to two weeks after planting, a second about a month later, and a third roughly two months after planting. On established June-bearing beds, do not feed in spring; spring nitrogen drives leaf growth, not fruit, and a dense canopy traps moisture and promotes gray mold. Instead, fertilize once at renovation, just after harvest, to build the flower buds for next year. Established day-neutral and everbearing plants, which fruit all season, take the same total split into monthly doses through summer with an optional August feeding. On sandy soil, divide every rate into more frequent, lighter applications.")
repl("fertilizer.notes_beginner", None,
  "Strawberries mainly need nitrogen, and when you feed depends on the type. The first year, give a little fertilizer two or three times spread across the season rather than one big dose. After that, the rule for June-bearing plants is simple: do not feed in spring, because it grows lots of leaves but not more berries, and the thick leaves trap dampness that causes mold. Feed them once instead, right after harvest when you cut the plants back. Day-neutral and everbearing plants, which fruit all summer, get small amounts spread across the months instead. If your soil is sandy, feed smaller amounts more often.")
repl("fertilizer.notify_message_seasoned", None,
  "Time to renovate and feed your June-bearing strawberries. Mow the old leaves, narrow the row, then apply about 0.4 to 0.6 ounces of nitrogen per 10 feet of row and water it in to set next year's crop.")
repl("fertilizer.notify_message_beginner", None,
  "Your June-bearing strawberries are ready for their after-harvest cutback and feeding. Mow the old leaves, then give the plants a balanced fertilizer and water it in to help next year's berries.")
repl("fertilizer.npk_hint_seasoned", None,
  "A balanced analysis such as 16-16-16 works well. Rates are given as actual nitrogen per length of row, so divide the nitrogen you need by the decimal nitrogen fraction of your product: about 0.4 to 0.6 ounces of nitrogen per 10 feet at renovation works out to roughly 2.5 to 3.75 ounces of 16-16-16 per 10-foot row.")
repl("fertilizer.npk_hint_beginner", None,
  "A balanced fertilizer like 16-16-16 (the three numbers are nitrogen, phosphorus, and potassium) is a good all-purpose choice. Follow the label rate for the row length you are feeding, and water it in after spreading.")
repl("fertilizer.amount_seasoned", None,
  "First year: about 0.5 to 0.8 ounces of nitrogen per 10 feet of row total, in two to three splits. Established June-bearers: about 0.4 to 0.6 ounces of nitrogen per 10 feet of row, all at once at renovation. Day-neutral and everbearing: about 0.1 to 0.2 ounces of nitrogen per 10 feet each month after spring growth begins, with an optional August dose.")
repl("fertilizer.amount_beginner", None,
  "A rough guide: feed a new bed lightly two or three times the first year. Feed an established June-bearing bed once, after harvest. Feed day-neutral or everbearing plants a little each month through summer. Use the label rate on your fertilizer for the length of your row.")
repl("fertilizer.sources", None, ["osu_ext", "umn_ext"])
repl("fertilizer.anchoring_urls", None, au("osu_ext", "umn_ext"))

# =====================================================================================
# WATERING block (register pairs + scalars + schedule_by_stage keyed to stage ids + anchor)
# =====================================================================================
repl("watering.frequency_seasoned", None,
  "About 1 to 1.5 inches of water per week through the growing season, adjusted for vigor, growth stage, soil, and weather. On sandy soil and in heat, water more often and more lightly. Newly set plants have undeveloped roots and stress easily, so irrigate several times a week until established.")
repl("watering.frequency_beginner", None,
  "Give strawberries about 1 to 1.5 inches of water a week while they are growing. Water more often in hot weather or sandy soil, and keep new plants well watered since their roots are still small.")
repl("watering.amount_seasoned", None,
  "Wet the soil to a depth of about 6 inches to 1 foot with each irrigation, enough that the shallow root zone does not fully dry between waterings, but never so much that water stands. Standing water harms strawberries even for a day or two.")
repl("watering.amount_beginner", None,
  "Water enough to wet the soil about 6 inches to a foot deep, so the roots stay moist but never soggy. Strawberry roots are shallow and rot if they sit in water, so do not overdo it.")
repl("watering.method_seasoned", None,
  "Drip irrigation is ideal: it keeps water off the foliage and fruit, which reduces gray mold and weeds. Run a single drip line per row with half-gallon emitters spaced about every 12 inches, or use a soaker hose while monitoring soil moisture.")
repl("watering.method_beginner", None,
  "The best way to water strawberries is at the base, not over the leaves, because wet leaves and fruit lead to mold. A drip line or soaker hose along the row works well; if you water by hand, water the soil rather than the plants.")
repl("watering.signs_overwater_seasoned", None,
  "Wilting despite wet soil, yellowing lower leaves, and soft or collapsing crowns signal waterlogging and the root and crown rots that follow. Standing water and slow-draining ground are the usual causes.")
repl("watering.signs_overwater_beginner", None,
  "If the soil is wet but the plants still wilt, the leaves yellow, or the crowns turn soft and mushy, you are watering too much or the ground drains poorly. Soggy soil rots strawberry roots.")
repl("watering.signs_underwater_seasoned", None,
  "Dull, wilting leaves in dry soil and small, soft berries point to drought stress. Because fruit is mostly water, under-watering during fruit development directly cuts size and yield.")
repl("watering.signs_underwater_beginner", None,
  "Drooping, dull leaves with dry soil, and small berries, mean the plants need more water. Strawberries especially need water while the fruit is filling out, or the berries stay small.")
repl("watering.watering_method", None, "drip")
repl("watering.drought_tolerance", None, "low")
repl("watering.method_note_seasoned", None,
  "Keep water off ripening fruit and foliage where possible. Overhead watering wets the canopy and raises gray mold pressure, so if you must use it, water early in the day so leaves and fruit dry quickly.")
repl("watering.method_note_beginner", None,
  "Try to keep water off the berries and leaves. If you can only water from above, do it in the morning so everything dries out during the day and does not stay damp.")
repl("watering.critical_periods_seasoned", None,
  "On established beds, two periods matter most: from just after bloom through harvest, when fruit is sizing, and from late summer into early fall, when next year's flower buds form. Do not let plants stress for water in either window.")
repl("watering.critical_periods_beginner", None,
  "Two times are most important for watering: while the berries are forming and ripening, and again in late summer to early fall when the plant is setting up next year's crop. Keep the soil from drying out during both.")
sched = [
  {"stage_id": "establishment", "system": "drip", "rate": "1 to 1.5 inches per week",
   "frequency": "several times per week", "level": "moderate",
   "note_seasoned": "Keep new plantings evenly moist; shallow, undeveloped roots stress quickly.",
   "note_beginner": "Keep new plants evenly watered so they do not dry out."},
  {"stage_id": "fruit_set", "system": "drip", "rate": "1 to 1.5 inches per week",
   "frequency": "as needed to keep soil evenly moist", "level": "steady",
   "note_seasoned": "Even moisture during fruit sizing drives berry size and quality; keep fruit off wet soil.",
   "note_beginner": "Water evenly while berries are filling out, and keep the fruit off wet ground."},
  {"stage_id": "renovation", "system": "drip", "rate": "1 to 1.5 inches per week",
   "frequency": "after mowing and feeding", "level": "moderate",
   "note_seasoned": "Irrigate right after renovation to push fresh leaf and runner growth.",
   "note_beginner": "Water right after you cut the plants back and feed them, to help them regrow."},
  {"stage_id": "dormancy", "system": "none", "rate": "rainfall in most regions",
   "frequency": "minimal", "level": "low",
   "note_seasoned": "Dormant beds need little water; avoid waterlogged soil over winter.",
   "note_beginner": "Dormant plants need almost no water; just do not let them sit in soggy soil."},
]
repl("watering.schedule_by_stage", [], sched)
repl("watering.sources", None, ["osu_ext", "umn_ext"])
repl("watering.anchoring_urls", None, au("osu_ext", "umn_ext"))

# =====================================================================================
# STORAGE block (register pairs + anchor). UC ANR 8256 + EC1307 harvest-store.
# =====================================================================================
repl("storage.room_temp_seasoned", None,
  "Strawberries are highly perishable and do not ripen further after picking, so hold them at room temperature only if eating within a day. For anything longer, refrigerate promptly; cool freshly picked fruit as soon as possible after harvest.")
repl("storage.room_temp_beginner", None,
  "Strawberries do not get sweeter after picking and spoil fast, so only leave them out if you will eat them that day. Otherwise, get them into the fridge soon after picking.")
repl("storage.fridge_seasoned", None,
  "Refrigerate unwashed in the crisper drawer, kept in a closed clamshell or a partially open plastic bag to hold humidity near 90 to 95 percent. Do not wash until just before use, since surface moisture speeds spoilage. Under good conditions berries keep up to about a week, depending on ripeness at picking.")
repl("storage.fridge_beginner", None,
  "Put the berries in the fridge unwashed, in their container or a loosely closed bag, and wash them only right before you eat them. Washing too early makes them mushy. Stored this way they last up to about a week, depending on how ripe they were.")
repl("storage.freezer_seasoned", None,
  "For long-term storage, hull the berries, spread them on a tray to flash-freeze, then transfer to airtight containers or bags. Held at 0 degrees F they keep good quality for up to about a year.")
repl("storage.freezer_beginner", None,
  "To keep strawberries for months, remove the green tops, freeze them spread out on a tray first so they do not clump, then pack them into airtight bags. In the freezer they keep for up to about a year.")
repl("storage.notes_seasoned", None,
  "Sort before storing and discard any bruised or molding fruit, since gray mold spreads quickly from one berry to the next. Pick and store fruit with the cap on for the longest shelf life.")
repl("storage.notes_beginner", None,
  "Before storing, pick out and toss any soft or moldy berries, because mold jumps quickly from one to another. Berries keep best with their green caps left on.")
repl("storage.sources", [], ["uc_anr_8256", "osu_ext"])
repl("storage.anchoring_urls", {}, au("uc_anr_8256", "osu_ext"))

# =====================================================================================
# YIELD_EXPECTATIONS block (register pairs + factors_seasoned single-register + anchor)
# =====================================================================================
repl("yield_expectations.per_plant_seasoned", None,
  "About 1 to 2 pounds per plant, or roughly 7 to 15 pounds per 10-foot row, varying with cultivar and planting age.")
repl("yield_expectations.per_plant_beginner", None,
  "Expect roughly 1 to 2 pounds of berries per plant, depending on the variety and how old the bed is.")
repl("yield_expectations.peak_production_seasoned", None,
  "Yield peaks the year after planting (year two). It is often similar or slightly lower in year three, and both berry size and total yield decline from years two to four.")
repl("yield_expectations.peak_production_beginner", None,
  "You will get the most berries the second year, the year after planting. After that the crop slowly tapers off in size and amount.")
repl("yield_expectations.first_year_note_seasoned", None,
  "Expect little or no crop in the planting year. On June-bearers the flowers are pinned off the first season by design, so a missing first-year harvest is the plan working, not a failure.")
repl("yield_expectations.first_year_note_beginner", None,
  "Do not expect berries the first year. On June-bearing plants you pick the flowers off on purpose, so no first-year crop is exactly what should happen.")
repl("yield_expectations.factors_seasoned", [], [
  "Cultivar and type: June-bearers concentrate yield in one flush; day-neutrals spread a similar or smaller total across the season.",
  "Planting age: highest in year two, declining through year four as the bed ages.",
  "Pollination: cold or wet bloom weather and few bees give small, grooved, or pinched berries.",
  "Water during fruiting: fruit is mostly water, so moisture stress during sizing cuts yield and berry size directly.",
  "Renovation and weed control on June-bearers: timely renovation and a weed-free, well-spaced row sustain yield across seasons.",
])
repl("yield_expectations.sources", [], ["osu_ext", "umn_ext"])
repl("yield_expectations.anchoring_urls", {}, au("osu_ext", "umn_ext"))

# =====================================================================================
# TOP-LEVEL register pairs: description, harvest_ready, bloom_time, hardiness_notes,
# chill_hours_note (N/A prose), soil_prep. Each anchored via its sibling sources field where present.
# =====================================================================================
repl("description_seasoned", None,
  "The garden strawberry is a low-growing herbaceous perennial with a short, compressed stem called the crown, from which leaves, flowers, and runners arise. It is grown in three types: June-bearing (one concentrated early-summer flush, the matted-row backbone of US backyard growing), day-neutral (fruiting through the season, compact, ideal for containers), and everbearing (two lighter flushes). Plants are self-fertile, set from dormant bare-root crowns or potted plugs, and a bed stays productive for about three to four fruiting seasons before it is replaced.")
repl("description_beginner", None,
  "Strawberries are low, leafy plants that come back year after year. There are three kinds: June-bearing, which gives one big batch of berries in early summer; day-neutral, which gives a few berries at a time all season and does great in pots; and everbearing, which gives two smaller batches. One plant makes fruit on its own, and a strawberry patch keeps producing for about three to four years before you start a fresh one.")
repl("harvest_ready_seasoned", None,
  "Fruit is ready when it is fully red and fragrant and pulls free easily; flavor is best when berries ripen on the plant. Color deepens after picking, so fruit picked at about 75 percent red stores slightly longer. Pick every one to three days, more often in warm weather, and pick before forecast rain to protect flavor and limit rot.")
repl("harvest_ready_beginner", None,
  "A strawberry is ready when it is bright red all over, smells sweet, and comes off the plant easily. Berries taste best left to ripen on the plant. Pick every day or two, more often when it is hot, and pick before heavy rain so the berries do not get watery or moldy.")
repl("harvest_ready_sources", [], ["osu_ext", "uc_anr_8256"])
repl("harvest_ready_anchoring_urls", {}, au("osu_ext", "uc_anr_8256"))
repl("bloom_time_seasoned", None,
  "On established beds, June-bearing plants flower in mid-spring, near the last-frost date, and fruit ripens about four weeks later. Day-neutral plants flower and fruit through the season whenever temperatures sit between about 40 and 90 degrees F. Open blossoms are frost-sensitive, so bloom timing and late frosts together set the crop.")
repl("bloom_time_beginner", None,
  "June-bearing strawberries flower in mid-spring, around the last frost, and the berries ripen about four weeks after that. Day-neutral plants flower on and off all season as long as it is not too cold or too hot. Open flowers can be killed by a late frost, so watch the weather while they bloom.")
repl("hardiness_notes_seasoned", None,
  "Strawberries grow across USDA zones 3 through 10, but how they are grown shifts with climate. In cold-winter regions they are a perennial matted-row bed that needs winter straw mulch, since crowns are injured between about 10 and 20 degrees F at the crown. In hot-summer regions, summer heat exhausts the planting, so strawberries are grown as a fall-set annual that is pulled and replaced each year. Choose cultivars matched to your winters; cold-hardy types and heat-adapted types are not interchangeable.")
repl("hardiness_notes_beginner", None,
  "Strawberries grow in most of the country, from cold zone 3 to warm zone 10, but the way you grow them changes with your climate. Where winters are cold, they live for years as a bed and need a straw cover in winter to protect the crowns. Where summers are hot, the heat wears the plants out, so people plant fresh ones each fall and pull them after one season. Pick a variety suited to your area.")
# chill_hours_note: N/A PROSE (informational, NOT a gate; per D8 + kickoff exact framing). chill scalars stay null.
repl("chill_hours_note_seasoned", None,
  "Strawberries need only modest winter chill, and chilling is not a limiting factor for the home grower the way it is for tree fruit. It is informational here, not a hardiness gate. Cultivar cold-hardiness and summer heat, not chill accumulation, decide where and how strawberries are grown.")
repl("chill_hours_note_beginner", None,
  "Strawberries do not need a set amount of winter cold to fruit, unlike apples or peaches. You do not have to count chill hours for them. What matters instead is choosing a variety that suits your winters and summers.")
repl("soil_prep_seasoned", None,
  "Strawberries want a fertile, well-drained sandy loam or loam rich in organic matter. Because the roots are shallow and rot in waterlogged soil, plant into a raised bed or mounded row about 12 inches high on heavy or slow-draining ground. Work 1 to 2 inches of compost into the bed before planting and adjust pH to 5.6 to 6.5 a season ahead, since sulfur or lime take months to act. Avoid ground that recently grew tomatoes, peppers, eggplant, potatoes, raspberries, or blackberries, which leave Verticillium wilt in the soil.")
repl("soil_prep_beginner", None,
  "Strawberries like loose, rich soil that drains well. Their roots are shallow and rot in soggy ground, so if your soil is heavy clay or puddles after rain, build a raised bed or mound about 12 inches tall and plant into that. Mix in an inch or two of compost before planting. Strawberries prefer slightly acidic soil, so test it the season before and adjust if needed. Do not plant where tomatoes, peppers, potatoes, or other berries grew recently, because they leave behind a soil disease that attacks strawberries.")
# soil_prep has no dedicated sources sibling in the slice's top-level shape; it is covered by soil.sources (already anchored).
# Confirm no orphan: soil_prep_* are top-level prose; their biology is the already-anchored soil/ph/rotation blocks.

# =====================================================================================
# COMPOUND BLOCKS: diseases, pests, failure_diagnostics, notifications, weather_triggers
# Shapes (Appendix A): pests/diseases = name,symptoms_*,cause_*,organic_treatment_*,prevention_*,severity,type,audience
#  failure_diagnostics = id,label_*,what_happened_*,next_season_tip_*,audience
#  notifications = id,title_*,body_*,action,trigger_type,offset_from,offset_days,condition,stage,audience
#  weather_triggers = id,title_*,body_*,action,severity,condition,audience
# =====================================================================================
def pd(name, sev, typ, sym_s, sym_b, cau_s, cau_b, org_s, org_b, prev_s, prev_b, audience="core"):
    return {"name": name, "severity": sev, "type": typ,
        "symptoms_seasoned": sym_s, "symptoms_beginner": sym_b,
        "cause_seasoned": cau_s, "cause_beginner": cau_b,
        "organic_treatment_seasoned": org_s, "organic_treatment_beginner": org_b,
        "prevention_seasoned": prev_s, "prevention_beginner": prev_b,
        "audience": audience}

diseases = [
  pd("Gray mold (Botrytis fruit rot)", "high", "fungal",
    "A soft, tan rot of green and ripe fruit that quickly becomes a fuzzy gray mold, often starting where berries touch soil, mulch, or another berry. It spreads fast through a picked basket.",
    "Berries turn soft and rot, then grow a gray fuzz. It often starts where a berry touches the ground or another berry, and spreads quickly.",
    "The fungus Botrytis cinerea, which overwinters on dead leaves and thrives when it rains during bloom and fruit development.",
    "A mold that lives on old dead leaves and takes hold when it is wet while the plants are flowering and fruiting.",
    "Remove and destroy infected berries the moment you see them. Keep an open, airy canopy, keep ripening fruit off wet soil, and clean out old leaves at renovation and in early spring.",
    "Pick off and throw away any moldy berries right away. Keep the plants from getting crowded, keep berries off wet ground, and clear away old dead leaves.",
    "Avoid spring nitrogen on June-bearers, which thickens the canopy and traps moisture. Water at the base rather than overhead, space plants for airflow, and pick fruit promptly and often.",
    "Do not feed June-bearing plants in spring, since extra leaves trap dampness. Water at the soil, give plants room to breathe, and pick ripe berries often.")
  ,
  pd("Anthracnose fruit rot", "medium", "fungal",
    "Dark, sunken, circular lesions on fruit; the fungus can also infect crowns and runners, causing wilting and plant death in warm, wet spells.",
    "Dark, sunken round spots on the berries. The disease can also rot the crown and runners, making plants wilt and die in warm, wet weather.",
    "Colletotrichum fungi, favored by warm, humid, rainy conditions during fruit development and spread by splashing water.",
    "A fungus that thrives in warm, wet, humid weather and splashes around in the rain.",
    "Remove and destroy diseased fruit and plants promptly. Reduce splash by watering at the base and mulching, and improve airflow.",
    "Pull off and throw away diseased berries and plants. Water at the soil instead of overhead, and give plants room.",
    "Start with certified disease-free plants, avoid overhead watering, and do not plant into ground with a recent history of the disease.",
    "Buy clean, certified plants, water at the base, and avoid spots where this disease has been a problem before.")
  ,
  pd("Powdery mildew", "low", "fungal",
    "Upward cupping and purpling of leaf edges with a white powdery film; in some cultivars infected fruit tastes bitter.",
    "Leaf edges curl upward and turn purple, with a white dusty coating. In some varieties the berries taste bitter.",
    "A fungus that, unlike most strawberry diseases, spreads in dry conditions with high humidity and moderate temperatures.",
    "A fungus that spreads when the air is humid but the leaves are dry.",
    "Remove badly affected leaves and improve airflow. Choose resistant cultivars where mildew is a recurring problem.",
    "Pick off the worst leaves and give plants more room. Grow varieties known to resist mildew if it keeps coming back.",
    "Space plants well, avoid dense canopies, and select tolerant cultivars.",
    "Give plants room, keep them from getting crowded, and choose mildew-resistant varieties.")
  ,
  pd("Red stele (Phytophthora root rot)", "medium", "fungal",
    "Stunted, wilting plants that collapse in spring; roots are rotted and, when sliced lengthwise, show a reddish-brown core. Worst in heavy, wet, poorly drained soil.",
    "Plants are stunted and wilt, then collapse in spring. If you cut a root open, the center is reddish-brown. It is worst in heavy, wet soil that drains poorly.",
    "Soilborne Phytophthora fungi that thrive in cold, saturated soils and persist for years.",
    "A soil fungus that builds up in cold, soggy ground and stays in the soil for years.",
    "There is no cure once plants are infected; remove and destroy affected plants. Improve drainage with raised beds and choose resistant cultivars.",
    "There is no cure once a plant has it, so pull and destroy sick plants. Build raised beds for better drainage and grow resistant varieties.",
    "Plant only in well-drained soil or raised beds, start with certified plants, and choose red-stele-resistant cultivars on wet sites.",
    "Plant in well-drained soil or raised beds, buy certified plants, and pick resistant varieties if your ground stays wet.")
  ,
  pd("Verticillium wilt", "medium", "fungal",
    "Outer leaves wilt, dry at the margins, and collapse while inner leaves may stay upright; plants are stunted and may die. Symptoms often appear as fruit load increases.",
    "The outer leaves wilt, dry at the edges, and flop down while the middle leaves stay up. Plants are stunted and may die, often as the berries are forming.",
    "The soilborne fungus Verticillium, which also infects tomatoes, peppers, eggplant, potatoes, and brambles and persists in soil for years.",
    "A soil fungus that also attacks tomatoes, peppers, potatoes, and other berries, and stays in the soil for years.",
    "There is no rescue treatment; remove affected plants. Manage it through rotation and resistant cultivars rather than cure.",
    "There is no cure, so remove sick plants. The real fix is where you plant and which variety you choose.",
    "Do not plant strawberries after or near tomatoes, peppers, eggplant, potatoes, raspberries, or blackberries, and start with certified disease-free stock on a clean site.",
    "Do not plant strawberries where you recently grew tomatoes, peppers, potatoes, or other berries, and start with certified clean plants.")
]
repl("diseases", [], diseases)

pests = [
  pd("Slugs", "medium", "mollusk",
    "Ragged holes chewed in ripe fruit and leaves, with slime trails, worst in damp, heavily mulched beds and wet weather.",
    "Ragged holes eaten in the berries and leaves, with shiny slime trails. Worst in damp, mulchy beds and wet weather.",
    "Slugs, which shelter in deep or wet mulch and feed at night on soft ripe fruit.",
    "Slugs, which hide in damp mulch and eat the soft ripe berries at night.",
    "Hand-pick in the evening, set out shallow traps, and remove damp hiding places. Keep ripening fruit off wet mulch.",
    "Pick them off in the evening, use simple traps, and clear away damp hiding spots. Keep berries off wet mulch.",
    "Avoid deep straw mulch during the growing season, keep the bed tidy, and harvest ripe fruit promptly.",
    "Do not pile on thick straw in summer, keep the bed clean, and pick ripe berries quickly.")
  ,
  pd("Spotted wing drosophila", "high", "insect",
    "Soft, collapsing spots on ripening and ripe fruit; tiny larvae feed inside berries. Populations build through the season, so later fruit is hit hardest.",
    "Soft, sunken spots on ripening berries, with tiny maggots inside. It gets worse later in the season.",
    "A vinegar fly that lays eggs in coloring fruit; the larvae feed inside as the berry ripens.",
    "A small fruit fly that lays eggs in the berries as they start to color, and the maggots eat the fruit from inside.",
    "Pick fruit frequently and completely, remove and destroy overripe and culled berries, and use fine exclusion netting on susceptible later crops.",
    "Pick all the ripe berries often, throw away overripe and damaged ones, and cover later crops with fine netting.",
    "Harvest on a tight schedule, never leave overripe fruit on the plant, and exclude adults with fine netting where pressure is high.",
    "Keep up with picking, never leave overripe berries on the plant, and use fine netting if the flies are bad.")
  ,
  pd("Tarnished plant bug (lygus)", "medium", "insect",
    "Catfaced fruit, dimpled and pinched at the tip with seedy, woody patches; most noticeable on day-neutrals in summer.",
    "Lumpy, dented berries with a pinched, seedy tip. Most common on day-neutral plants in summer.",
    "Lygus bugs feeding on developing flowers and fruit, which disrupts seed and berry development at the tip.",
    "A small bug that feeds on the flowers and young fruit, which makes the berry tip grow lumpy.",
    "Keep the bed and surrounding area weed-free to remove alternate hosts, and monitor flowers during fruiting.",
    "Keep weeds down in and around the bed, since the bugs live on them, and watch the flowers while fruiting.",
    "Control broadleaf weeds that host lygus near the planting and keep the bed clean through the season.",
    "Pull broadleaf weeds near the bed, since the bugs breed on them, and keep the area tidy.")
  ,
  pd("Aphids", "low", "insect",
    "Clusters of small soft-bodied insects on new growth and leaf undersides, with sticky honeydew and sometimes sooty mold; aphids can also transmit strawberry viruses.",
    "Groups of tiny soft bugs on new leaves and leaf undersides, leaving a sticky film. They can also spread plant viruses.",
    "Aphids feeding on plant sap, building up quickly on tender new growth.",
    "Aphids, tiny bugs that suck plant juices and multiply fast on new leaves.",
    "Knock populations back with a strong spray of water, encourage natural predators such as lady beetles, and use insecticidal soap on heavy infestations.",
    "Spray them off with water, let helpful bugs like ladybugs do their work, and use insecticidal soap if there are a lot.",
    "Start with clean, certified plants to limit virus introduction, and avoid excess nitrogen that flushes soft, aphid-prone growth.",
    "Start with clean plants, and do not over-feed, since lots of soft new growth attracts aphids.")
  ,
  pd("Two-spotted spider mite", "medium", "mite",
    "Fine stippling and bronzing of leaves with faint webbing on undersides, worst in hot, dry, dusty conditions; heavy infestations weaken plants and reduce yield.",
    "Leaves look speckled and bronzed, with fine webbing underneath. Worst in hot, dry, dusty weather, and bad cases weaken the plants.",
    "Tiny mites that feed on the underside of leaves and multiply rapidly in hot, dry weather.",
    "Tiny mites under the leaves that multiply fast when it is hot and dry.",
    "Rinse foliage to raise humidity and dislodge mites, encourage predatory mites, and treat severe cases with horticultural oil or insecticidal soap.",
    "Spray the leaves with water to knock mites off and raise humidity, and use horticultural oil or soap for bad cases.",
    "Avoid drought stress and dusty conditions, and keep plants well watered in heat.",
    "Keep plants watered in hot weather and avoid letting them get dusty and dry.")
  ,
  pd("Root and crown weevils (black vine weevil)", "medium", "insect",
    "Notched leaf margins from night-feeding adults, and stunted, wilting, or collapsing plants whose roots and crowns have been eaten by larvae.",
    "Leaf edges notched as if cut with pinking shears, and plants that wilt or collapse because grubs have eaten the roots and crown.",
    "Weevils whose adults notch leaves at night and whose larvae feed underground on roots and crowns.",
    "Beetles whose adults chew the leaf edges at night and whose grubs eat the roots underground.",
    "Inspect on warm evenings and remove adults; beneficial nematodes can target soil-dwelling larvae. Remove and destroy heavily infested plants in fall.",
    "Look for the beetles on warm evenings and remove them. Beneficial nematodes can attack the grubs in the soil. Pull badly infested plants in fall.",
    "Rotate to a fresh site when starting a new bed, since larvae build up in older plantings, and start with clean stock.",
    "Start new beds in a fresh spot, since the grubs build up in old beds, and use clean plants.")
  ,
  pd("Birds", "medium", "vertebrate",
    "Pecked and partly eaten ripe berries, often the first fully colored fruit taken just before you would pick it.",
    "Ripe berries pecked or half-eaten, often the best red ones taken right before you pick them.",
    "Birds attracted to ripening red fruit.",
    "Birds that go for the ripe red berries.",
    "Drape bird netting over the bed as fruit colors, or use floating row cover, keeping it secured at the edges.",
    "Cover the bed with bird netting or a light cloth as the berries turn red, tucking the edges down.",
    "Net the planting before the first fruit ripens rather than after birds find it.",
    "Put netting on before the first berries ripen, not after the birds have already found them.")
]
repl("pests", [], pests)

def fd(id_, label_s, label_b, wh_s, wh_b, tip_s, tip_b, audience="core"):
    return {"id": id_, "label_seasoned": label_s, "label_beginner": label_b,
        "what_happened_seasoned": wh_s, "what_happened_beginner": wh_b,
        "next_season_tip_seasoned": tip_s, "next_season_tip_beginner": tip_b, "audience": audience}

failure_diagnostics = [
  fd("runners_no_fruit",
    "Lots of runners and leaves, but little or no fruit",
    "Big leafy plants and lots of runners, but hardly any berries",
    "Heavy leaf and runner growth at the expense of fruit usually means too much nitrogen, spring feeding on an established June-bearing bed, or, in year one, the normal result of pinching flowers to establish the plant.",
    "Too much nitrogen, or feeding a June-bearing bed in spring, pushes leaves and runners instead of berries. In the first year, no fruit is normal because you pinch the flowers off on purpose.",
    "Feed June-bearers only at renovation, not in spring, and keep total nitrogen modest. Remember that a fruitless first year on a June-bearing bed is the plan, with the real crop coming in year two.",
    "Feed June-bearing plants only after harvest, not in spring, and do not overdo the fertilizer. And remember the first year is supposed to be fruitless, with the big crop the second year.")
  ,
  fd("small_misshapen_fruit",
    "Small, lumpy, or pinched-tip berries",
    "Small, lumpy, or pinched berries",
    "Misshapen or grooved fruit comes from poor pollination during cold or wet bloom weather, or from tarnished plant bug feeding that pinches the berry tip (catfacing).",
    "Lumpy or pinched berries usually mean the flowers were not pollinated well in cold or wet weather, or a small bug fed on them and deformed the tip.",
    "Protect bloom from frost, pull row covers back so bees can work the flowers, and control broadleaf weeds that host tarnished plant bug.",
    "Cover flowers only when frost threatens and open them up for bees otherwise, and keep weeds down to reduce the bugs that deform the tips.")
  ,
  fd("gray_fuzz_fruit",
    "Berries rotting with gray fuzz",
    "Berries rotting with gray fuzz",
    "Soft fruit covered in gray fuzz is gray mold (Botrytis), driven by wet conditions, a dense canopy, fruit resting on wet soil, and rain during bloom and ripening.",
    "Gray fuzzy rot on the berries is a mold that takes hold when things stay wet, the plants are crowded, or berries sit on damp ground.",
    "Open up the canopy by skipping spring nitrogen on June-bearers, water at the base, keep fruit off wet soil, clean out old leaves, and pick ripe fruit promptly.",
    "Give the plants more air by not feeding June-bearers in spring, water at the soil, keep berries off wet ground, clear old leaves, and pick ripe berries quickly.")
  ,
  fd("no_fruit_year_one",
    "No fruit at all in the first year",
    "No berries the first year",
    "On a June-bearing bed this is expected and correct: flowers are pinned off the first season so the plant builds roots, crown, and a matted row, with the first real crop in year two.",
    "On June-bearing plants this is normal. You pick the flowers off the first year so the plant gets strong, and the first real crop comes the second year.",
    "Stay the course: pinch first-year flowers on June-bearers and let runners fill the row. For fruit the first year, grow a day-neutral type, which fruits in its planting season.",
    "Keep pinching the flowers off June-bearing plants the first year and let the runners fill in. If you want berries the first year, grow a day-neutral type instead.")
  ,
  fd("winter_crown_kill",
    "Plants dead or stunted after winter, with blackened crowns",
    "Plants dead or weak after winter, with dark mushy crowns",
    "Winter cold injury: strawberry crowns are damaged between about 10 and 20 degrees F at the crown, especially without snow cover or winter mulch in cold regions, or with a poorly cold-hardy cultivar.",
    "Winter cold killed the crowns. This happens in cold areas when there is no snow or straw cover, or when the variety is not hardy enough for your winters.",
    "In cold regions, apply 2 to 3 inches of loose straw after the first hard freeze and remove it in early spring, and choose cultivars rated for your hardiness zone. Skip straw in wet-winter regions, where it causes crown rot instead.",
    "In cold places, cover the plants with 2 to 3 inches of straw after the first hard freeze and uncover them in spring, and pick a variety hardy for your area. In mild, rainy places, skip the straw, since it makes the crowns rot.")
]
repl("failure_diagnostics", [], failure_diagnostics)

# NOTIFICATIONS (machinery keys per Appendix A: action, trigger_type, offset_from, offset_days, condition, stage, id)
def notif(id_, title_s, title_b, body_s, body_b, action, trigger_type, offset_from, offset_days, condition, stage, audience="core"):
    return {"id": id_, "title_seasoned": title_s, "title_beginner": title_b,
        "body_seasoned": body_s, "body_beginner": body_b,
        "action": action, "trigger_type": trigger_type, "offset_from": offset_from,
        "offset_days": offset_days, "condition": condition, "stage": stage, "audience": audience}

notifications = [
  notif("plant_window", "Time to plant strawberries", "Time to plant your strawberries",
    "Your strawberry planting window is open. Set dormant bare-root crowns or potted plugs with the crown midpoint level with the soil surface.",
    "It is time to plant your strawberries. Set each plant so the middle of the crown sits right at soil height.",
    "log_planting", "stage", None, None, None, "plant"),
  notif("pinch_flowers_y1", "Pinch first-year flowers", "Pick off the flowers this year",
    "On June-bearing plants, pinch off flowers through the first season so the plant builds roots, crown, and runners for a full year-two crop.",
    "On June-bearing plants, pick off the flowers this first year so the plant grows strong and gives a big crop next year.",
    "remind", "stage", None, None, None, "establishment"),
  notif("frost_on_bloom", "Frost risk during bloom", "Frost coming while plants are flowering",
    "Frost is forecast during bloom. Open blossoms are injured at about 30 degrees F. Cover the bed with row cover in the late afternoon and remove it in the morning once the danger passes.",
    "Frost is coming while your strawberries are flowering. Cover the plants with a light cloth in the evening and take it off in the morning.",
    "frost_protect", "weather", None, None, "FROST_DURING_BLOOM", "bloom"),
  notif("harvest_window", "Strawberry harvest is starting", "Your strawberries are ready to pick",
    "Fruit is ripening. Pick fully red berries every one to three days, more often in warm weather, and refrigerate promptly.",
    "Your strawberries are starting to ripen. Pick the fully red ones every day or two and get them into the fridge.",
    "remind", "stage", None, None, None, "harvest"),
  notif("renovation_reminder", "Renovate your June-bearing bed", "Time to cut back your June-bearing bed",
    "Within one to two weeks of your last picking, mow the old leaves to about 2 inches above the crowns, narrow the row, then fertilize and water to set next year's crop.",
    "A week or two after your last berries, mow the old leaves to about 2 inches above the crowns, narrow the row, then feed and water the plants.",
    "remind", "stage", None, None, None, "renovation"),
  notif("winter_mulch", "Mulch for winter (cold regions)", "Cover the plants for winter (cold areas)",
    "In cold regions, after the first hard freeze, cover the bed with 2 to 3 inches of loose straw to protect the crowns. Skip this in wet-winter regions, where straw causes crown rot.",
    "In cold areas, after the first hard freeze, cover the plants with 2 to 3 inches of loose straw to protect them. Skip this if your winters are mild and rainy.",
    "remind", "stage", None, None, None, "dormancy"),
]
repl("notifications", [], notifications)

# WEATHER_TRIGGERS (machinery keys: action, severity, condition, id)
def wt(id_, title_s, title_b, body_s, body_b, action, severity, condition, audience="core"):
    return {"id": id_, "title_seasoned": title_s, "title_beginner": title_b,
        "body_seasoned": body_s, "body_beginner": body_b,
        "action": action, "severity": severity, "condition": condition, "audience": audience}

weather_triggers = [
  wt("frost_bloom", "Frost during bloom", "Frost while flowering",
    "A frost is forecast while plants are in bloom. Open flowers are injured at about 30 degrees F and closed flowers at about 28 degrees F. Apply row cover in the late afternoon and remove it after the morning thaw.",
    "Frost is coming while your plants are flowering. Cover them with a light cloth in the late afternoon and uncover them once it warms up in the morning.",
    "frost_protect", "high", "TEMP_BELOW_32_DURING_BLOOM"),
  wt("heat_pause", "High heat slows fruiting", "Hot weather pauses the berries",
    "Sustained temperatures of 90 degrees F or higher pause flower formation on day-neutral plants until it cools. Keep soil evenly moist and consider afternoon shade in extreme heat.",
    "When it stays 90 degrees F or hotter, day-neutral plants stop setting new flowers until it cools down. Keep the soil evenly watered and give some afternoon shade in extreme heat.",
    "monitor", "medium", "TEMP_ABOVE_90"),
  wt("heavy_rain_harvest", "Rain forecast during harvest", "Rain coming while berries ripen",
    "An extended rain is forecast during ripening. Rain dilutes flavor and promotes gray mold, so pick fruit that is 75 percent to fully red before it arrives.",
    "A lot of rain is coming while your berries ripen. Rain makes them watery and moldy, so pick the riper berries before it hits.",
    "harvest_now", "medium", "RAIN_DURING_HARVEST"),
  wt("hard_freeze_winter", "Hard freeze in cold regions", "Hard freeze coming (cold areas)",
    "A hard freeze is forecast. Strawberry crowns are injured between about 10 and 20 degrees F. In cold regions, ensure winter straw mulch is in place; protect or relocate containers, whose roots freeze harder than in-ground beds.",
    "A hard freeze is coming. In cold areas, make sure your straw winter cover is on. Move or protect pots, since roots in pots get colder than roots in the ground.",
    "protect", "high", "HARD_FREEZE"),
]
repl("weather_triggers", [], weather_triggers)

# =====================================================================================
# DEFERRED ITEM 1: day-neutral type story -> extend type_selection_* (already authored; APPEND a companion).
# type_selection_* is non-null (don't clobber). The kickoff says "extend ... or its companion prose".
# The existing type_selection_* ALREADY carries the June/day-neutral/everbearing + container story (read live).
# So the deferred "day-neutral type story" is ALREADY PRESENT. Verify, do not duplicate. -> handled as a finding, not a write.
#
# DEFERRED ITEM 2: ca_interior small fall crop -> surface in harvest prose / type story.
# The fall-crop story lives in ca_interior region_notes_seasoned + grown_as_note_seasoned (read live; present).
# Surface it for the grower in harvest_ready (top-level) WITHOUT contradicting the region cell.
# harvest_ready_* already authored above with the general harvest story; the ca_interior nuance is region-scoped
# and correctly lives in the region cell. Adding a valley-specific clause to the universal harvest_ready_* would
# leak a region detail into crop-level prose. -> surface via a note flag to Trevor, not a crop-level write.
# Both deferred items are therefore ALREADY HOMED in authored prose; see findings. (No-clobber respected.)

# =====================================================================================
# EMIT
# =====================================================================================
# =====================================================================================
# NORMALIZE user-facing prose: 'degrees F' -> '°F' (v1.6 A3: °F is the user-facing canonical).
# Apply ONLY to register/prose leaves, never to machinery enum keys.
# =====================================================================================
import re as _re
_MACHINERY = {'action','trigger_type','offset_from','offset_days','condition','stage','id','severity','type',
              'system','watering_method','drought_tolerance','timing','example_product','notify_days_after',
              'stage_id','url','verified','year_phase','name','audience','day_range_from_sow'}
def _normalize(obj, key=None):
    if isinstance(obj, dict):
        return {k: _normalize(v, k) for k,v in obj.items()}
    if isinstance(obj, list):
        return [_normalize(v, key) for v in obj]
    if isinstance(obj, str) and key not in _MACHINERY:
        # "30 degrees F" / "10 and 20 degrees F" / "90 degrees F or hotter" -> "30 °F"
        s = _re.sub(r'\s*degrees?\s*F\b', ' °F', obj)
        s = _re.sub(r'\s+°F', ' °F', s)
        return s
    return obj
for op in patches:
    op['value'] = _normalize(op['value'])

# Both deferred items revisited against live prose:
# ITEM 1 (day-neutral type story): type_selection_* already covers the three types + day-neutral
#   through-season + containers, BUT lacks the mild-coast near-year-round day-neutral window the
#   kickoff says belongs in the TYPE narrative (not the region cells). -> APPEND one sentence per register.
# ITEM 2 (ca_interior fall crop): already surfaced in ca_interior region_notes_seasoned + the cell's
#   grown_as_note_seasoned (user-facing region prose, the correct home for a valley-specific detail).
#   Adding it to crop-level harvest_ready_* would leak a region detail into universal prose. -> NO write; disposition logged.

_TS_S_OLD = ("Strawberries come in three types, and the choice shapes your whole season. June-bearing cultivars set flower buds in the short days of fall and deliver one concentrated crop over about four weeks in late spring or early summer; they throw the most runners, so they suit a matted row and give a large flush ideal for freezing and jam. Their first real crop comes the season after planting. Day-neutral cultivars flower regardless of day length whenever temperatures sit between about 40 and 90 degrees, so they fruit from late spring through fall, bear in their first season, and throw few runners, which makes them the pick for containers, raised beds, and a steady supply of fresh berries. Everbearing cultivars give two lighter crops, one in early summer and one in late summer, and are generally less productive than day-neutrals. This guide follows the June-bearing matted-row model because it is the backbone of US backyard strawberry growing; the day-neutral notes throughout tell you where the care diverges.")
_TS_S_ADD = " In mild-winter coastal regions, day-neutral plantings can fruit across much of the year and are often grown as a fall-set annual rather than a long-lived bed, which is why the warm-region notes treat them differently from the cold-region matted row."
repl("type_selection_seasoned", _TS_S_OLD, _TS_S_OLD + _TS_S_ADD)

_TS_B_OLD = ("There are three kinds of strawberries, and picking the right one matters more than picking a fancy variety. June-bearing types give you one big harvest over about four weeks in late spring or early summer, perfect if you want a pile of berries at once for jam or the freezer. They spread by sending out runners that fill in a wide row, and they give their first real crop the year after you plant them. Day-neutral types fruit a little at a time from late spring all the way to fall, give berries the first year, and stay compact, so they are the best choice for pots and small raised beds. Everbearing types fall in between, with one crop in early summer and another in late summer. This guide is built around the June-bearing kind grown in a wide row, since that is how most home gardeners grow strawberries, and it points out along the way where day-neutrals are handled differently.")
_TS_B_ADD = " In mild coastal areas with gentle winters, day-neutral plants can give berries through much of the year, and gardeners there often plant fresh ones each year instead of keeping a bed for years."
repl("type_selection_beginner", _TS_B_OLD, _TS_B_OLD + _TS_B_ADD)

patch = {"base_sha": FULL_BASE_SHA, "session": "strawberry_steps_6_8", "patches": patches}
open("/home/claude/strawberry_6_8_patch.json", "w").write(json.dumps(patch, ensure_ascii=False, indent=2))

# ---- self-check: simulate apply on the slice + run register_fill style scan ----
sim = copy.deepcopy(crop)
def set_path(obj, dotted, value):
    # dotted is the crop-relative path with [N] indices; we only have simple forms here
    import re
    toks = re.findall(r"[^.\[\]]+|\[\d+\]", dotted)
    cur = obj
    for i, t in enumerate(toks):
        last = (i == len(toks)-1)
        if t.startswith("["):
            idx = int(t[1:-1])
            if last: cur[idx] = value
            else: cur = cur[idx]
        else:
            if last: cur[t] = value
            else: cur = cur[t]

for op in patches:
    rel = op["json_path"].split("]." , 1)[1]  # strip the $.crops[?(...)] prefix
    set_path(sim, rel, op["value"])

# register-fill scan: every *_seasoned/_beginner that is None is a miss
def scan_nulls(obj, path=""):
    misses = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            p = f"{path}.{k}" if path else k
            if (k.endswith("_seasoned") or k.endswith("_beginner")) and v is None:
                misses.append(p)
            misses += scan_nulls(v, p)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            misses += scan_nulls(v, f"{path}[{i}]")
    return misses

# allowlist: the two held-back boundary scalars are NOT register fields; hawaii is region prose (already authored).
worklist = [
 "fertilizer.notes","fertilizer.notify_message","fertilizer.npk_hint","fertilizer.amount",
 "watering.frequency","watering.amount","watering.method","watering.signs_overwater","watering.signs_underwater","watering.method_note","watering.critical_periods",
 "storage.room_temp","storage.fridge","storage.freezer","storage.notes",
 "yield_expectations.per_plant","yield_expectations.peak_production","yield_expectations.first_year_note",
 "description","harvest_ready","bloom_time","hardiness_notes","chill_hours_note","soil_prep",
]
misses = scan_nulls(sim)
# filter to worklist roots
worklist_misses = [m for m in misses if any(m.startswith(w+"_") or m==w+"_seasoned" or m==w+"_beginner" for w in worklist)]
compound_empty = [k for k in ["growth_stages","notifications","weather_triggers","pests","diseases","failure_diagnostics"] if len(sim[k])==0]

print("=== SELF-CHECK ===")
print("ops:", len(patches))
print("worklist register misses (should be 0):", len(worklist_misses))
for m in worklist_misses: print("   MISS:", m)
print("empty compound arrays (should be 0):", compound_empty)
print("ALL remaining _seasoned/_beginner nulls in crop (incl. allowlist):")
for m in misses: print("   null:", m)
# recompute crop SHA of simulated result (informational; Claude Code computes post_apply on full file)
sim_sha = hashlib.sha256(json.dumps(sim, separators=(',',':'), ensure_ascii=False, sort_keys=True).encode()).hexdigest()
print("simulated post-author crop SHA:", sim_sha)
