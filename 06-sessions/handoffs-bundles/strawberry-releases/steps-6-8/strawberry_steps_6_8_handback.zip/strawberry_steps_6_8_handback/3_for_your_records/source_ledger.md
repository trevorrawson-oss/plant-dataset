# Strawberry Steps 6-8 -- T1 source-fact ledger (for anchoring)

Catalogued T1 sources in play (all verified 2026-06-18 in existing crop):
- osu_ext  -- OSU EC1307 (FETCHED FULL this session) https://extension.oregonstate.edu/catalog/ec-1307-growing-strawberries-your-home-garden
- umn_ext  -- UMN Growing strawberries home garden  https://extension.umn.edu/fruit/growing-strawberries-home-garden
- umd_ext  -- UMD Growing strawberries home garden  https://extension.umd.edu/resource/growing-strawberries-home-garden
- usu_ext  -- USU Strawberries in the Garden        https://extension.usu.edu/yardandgarden/research/strawberries-in-the-garden
- cornell_ext, msu_ext, ncsu_ext, uc_ipm (catalogued)
- NEW to mint: uc_anr_8256 -- UC ANR Pub 8256 "Strawberries: Safe Methods to Store, Preserve, and Enjoy" (2007), DOI 10.3733/ucanr.8256
  canonical PDF https://anrcatalog.ucanr.edu/pdf/8256.pdf ; mirror https://escholarship.org/uc/item/5pw3p4tq
  NOTE: body JS/PDF-gated this session (umn_not_fetched pattern) -> log blocks_launch:false open finding, corroborated by EC1307 harvest-store text.

## EC1307 (osu_ext) -- FETCHED, anchors most blocks
FERTILIZER (per 10 ft row, N basis):
- New plantings (all types): total 0.5-0.8 oz N/10 ft, SPLIT: 0.2 oz at 1-2 wk after planting; 0.2-0.4 oz ~1 mo later; 0.1-0.2 oz ~2 mo after planting. More splits on sandy soil.
- Established June-bearing: 0.4-0.6 oz N/10 ft ALL AT ONCE at renovation (after harvest). Do NOT spring-feed (leaf growth not fruit; dense canopy -> fruit rot). Weak plantings only: 0.2-0.3 oz at spring growth.
- Established day-neutral/everbearing: 0.1-0.2 oz N/10 ft EACH MONTH x3 after spring growth begins + 0.1-0.2 oz in August (optional, vigor/region).
- 16-16-16 example: 2 oz N -> 12.5 oz product (2/0.16). Broadcast on dry plants; brush/wash off leaves or irrigate after.
- Container: ~1 plant per foot of row; slow-release per label or soluble weekly.
WATERING:
- 1-1.5 in/week growing season (varies vigor/stage/soil/weather).
- Wet soil to 0.5-1 ft each irrigation; don't let root zone fully dry between; no standing water.
- Sandy soils: more frequent + lighter.
- Newly set plants: shallow roots, easily stressed -> irrigate several times/week.
- Drip ideal (1 line/row, 1/2-gal emitters @ 12 in) or soaker; reduces disease/weeds.
- Critical: fruit is mostly water -> sufficient water during fruit production essential for yield + quality.
YIELD:
- 1-2 lb/plant OR 7-15 lb/10-ft row (varies cultivar + age).
- Highest Year 2 (year after planting); similar/lower Year 3; size + yield decline Years 2->4.
HARVEST:
- Ripe = fully red; flavor best ripened on plant.
- 75% red stores longer (color deepens after picking).
- If long rain forecast: pick 75%-full red (rain dilutes flavor + fruit rot).
- Pick WITH cap/calyx for shelf life/storage; processing cultivars pull capless when fully ripe.
- Check more often in warm weather/rain.
GROWTH/LIFECYCLE FRAME:
- Crown = short compressed stem; whorl of leaves, flowers/fruit, branch crowns, runners (stolons + daughters). Daughters root on soil contact.
- June-bearer: 1 crop late spring/early summer (~June Willamette; ~July E Oregon), ~4 wk season; fruits first time YEAR AFTER planting; most runners -> matted row.
- Day-neutral: fruit all season except <40F or >=90F; first fruit SAME year; few runners -> containers/hill. WV: May-early Oct.
- Everbearing: 2 crops (June season + late summer); late-summer crop in planting year; few runners.
- Full production Year 2 (all types); productive 2-4 fruiting seasons (2-5 yrs ground).
- Flower bud development in June-bearers occurs LATE SUMMER for next year's crop.
- Matted row: rows 3-4 ft center-center; plants ~15 in; early runners (before Sept 1) root; keep row 12-18 in; sweep runners into row.
YEAR ONE / RUNNERS:
- June-bearers: little fruit planting year, "no flower pruning necessary" (EC1307 wording) -- BUT removing blossoms is widely recommended (metro MG: best to remove blossoms first summer). Existing year_one_notes_* says pinch all season for June-bearers; KEEP consistent (don't contradict authored prose). Day-neutral/everbearing: remove first inflorescence/first flush, allow bloom after ~July 1.
RENOVATION (June-bearing only; matches authored renovation_*):
- ~1-2 wk after last harvest (late July/early Aug WV). Mow leaves ~2 in above crown (don't cut crown). Rake/remove debris (cuts fruit rot). Narrow matted row to 10-12 in. Fertilize + irrigate. Do NOT renovate day-neutral/everbearing (still fruiting).
PLANTING DEPTH (matches start_method notes_*):
- Midpoint of crown level with soil surface; topmost root just below surface, not exposed. Too deep -> growing tip smothers/rots; too high -> roots dry.
WINTER COLD:
- Crowns damaged 10-20F (at crown), depends on dormancy stage.
- Cold regions (central/E/SE Oregon): 2-3 in loose straw after temps first drop below freezing in fall; remove (rake to aisles) once severe cold past.
- Do NOT straw-mulch wet-winter west OR rainy microclimates -> rot under wet mulch.
- Containers: root ball freezes harder; move to unheated garage/shed or sink pot to rim + mulch; bring out at spring growth. (Matches container_notes.overwintering.)
FROST ON BLOOM (matches frost_risk_note per cell):
- Open flowers injured at 30F; closed flowers at 28F. Blackened centers -> no fruit. Partial -> "monkey-faced"/pinched berry.
- Row cover late afternoon/evening to trap heat; remove morning after frost danger. Bring small containers in.
POLLINATION (matches pollinator_notes_*):
- Self-fertile; one cultivar fruits. Rain/cool during bloom reduces set (direct + fewer bee visits). Poor pollination -> grooved/pinched fruit.
DISEASES:
- Botrytis (gray mold): THE fruit rot; overwinters on dead plant material; worse when rain during bloom + fruit dev; infects green + ripe fruit. Manage: open canopy (no spring N on June-bearers), remove old leaves at renovation, clean overwintering leaves early spring, remove diseased fruit.
- Anthracnose fruit rot: warm/humid/rainy fruit dev; dark sunken circular lesions; infects all parts incl crown/runners.
- Powdery mildew: leaf edge upward cupping + purpling; can make fruit bitter.
- Root rots + Verticillium wilt (soilborne). Verticillium hosts: potatoes, tomatoes, peppers, eggplant, raspberries, blackberries -> don't follow/precede. (Matches rotation.)
- Leather rot also mentioned. Red stele (Phytophthora, wet soils) -- from kickoff biology pointer + varieties note (Jewel prone to red stele); EC1307 names root rots generally. Author red stele as wet-soil root disease, anchor to crop + note variety susceptibility.
PESTS:
- Spotted wing drosophila (SWD): lays in coloring/ripe fruit; larvae inside; worse late-season; exclusion netting.
- Strawberry crown moth: larvae bore crown; remove old leaves at renovation.
- Black vine weevil/root weevil: adults notch leaves at night, larvae eat roots/crown.
- Lygus/tarnished plant bug (TPB): feeds on fruit -> malformed/catfaced berry tips (esp day-neutral summer).
- Slugs: love fruit; deep straw harbors them.
- Birds/deer/squirrels/mice (vertebrate): netting/row cover. Voles/field mice under plastic mulch.
- Two-spotted spider mite, aphids (general berry pests; kickoff pointer) -- aphids also virus vectors.

## UC ANR 8256 (uc_anr_8256) -- storage T1 (body JS-gated; facts from search snippets + catalog)
- Optimum storage humidity 90-95% (prevents water loss/shriveling).
- Store in crisper drawer; keep in closed plastic clamshell OR partially-open plastic bag (maintain high humidity).
- Do NOT wash until just before eating/preserving (water -> faster spoilage).
- Fresh storage: up to 7 days under optimum conditions (depends on ripeness at pick).
- Cool freshly-picked berries ASAP after harvest; refrigerate until use.
- Freeze for up to ~1 year; refrigerate if using sooner.
- Strawberry is achene/'false fruit', rose family.
ROOM TEMP (corroborated, standard food-safety + UC ANR posture "refrigerate ASAP"):
- Highly perishable; do not ripen after picking; only hold at room temp if eating within ~1 day.
FREEZER 0F:
- 0F (-18C) for long-term; standard (USDA/NCHFP). Hull, flash-freeze on tray, then airtight bag/container.

## Numeric fidelity flags (for Step 11 numeric check)
- Fertilizer per-10-ft numbers are EC1307 Tables 3-4 (0.5-0.8 new; 0.4-0.6 June-bearer renovation; 0.1-0.2 x monthly day-neutral). DO NOT import the third-party "1/2 cup ammonium sulfate" pattern (that was the onion-session error analog). Use N-per-row + 16-16-16 example only.
- Watering 1-1.5 in/wk + wet 0.5-1 ft: EC1307 verbatim-range, paraphrase.
- Yield 1-2 lb/plant, 7-15 lb/10 ft: EC1307.
- Storage 7 days / humidity 90-95% / freeze 1 yr: 8256.
