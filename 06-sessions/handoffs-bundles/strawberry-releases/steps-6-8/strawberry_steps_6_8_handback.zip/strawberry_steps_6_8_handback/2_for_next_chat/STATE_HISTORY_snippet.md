## 2026-06-19 -- strawberry Steps 6-8 (bulk prose + compound blocks, cert-prep leg) [anchor 13]

**Lane:** claude.ai (authoring). **Start SHA (full file):** `ec0bf9d0529eca6d5352d7eb9fa005f3182750b09e0c4288b833ee44fc2caee2` (LATEST.txt).
**Slice integrity preflight:** strawberry crop SHA `f42aaf47aeebd78575bd160f8429aeb5bd1fbcae52be02e0f75ac00c15c92807` -- confirmed against SLICE_INTEGRITY.md (faithful to canonical). Authored against the slice; Claude Code applies against the full file.
**Patch:** `strawberry_6_8_patch.json`, 76 ops (handoff format v1.0, RFC-6901, drift-guarded). Session id `strawberry_steps_6_8`.

### What changed (all crop-relative to `$.crops[?(@.slug=='strawberry')]`)
- **growth_stages** (was []): 8-stage perennial arc, ids `plant -> establishment -> runner -> bloom -> fruit_set -> harvest -> renovation -> dormancy`. Peach 13-key shape (id, name, day_range_from_sow:null, year_phase, timing_*, what_to_look_for_*, user_action_*, log_prompt_*, audience). All `audience: core`. **These ids are the references** for fertilizer.stage_id + schedule_by_stage[].stage_id + notifications.stage.
- **fertilizer** (register pair + ALL structured scalars closed): notes_*, notify_message_*, npk_hint_*, amount_* + frequency, type(`balanced_granular`), timing(`renovation`), example_product, notify_days_after(null -- stage-anchored not day-offset), stage_id(`renovation`). Anchored osu_ext + umn_ext. EC1307 N-rates (new 0.5-0.8 oz N/10ft split; established June-bearer 0.4-0.6 oz at renovation; day-neutral 0.1-0.2 oz monthly + Aug; 16-16-16 example 2.5-3.75 oz/10ft).
- **watering** (register pairs + scalars + schedule_by_stage): frequency_*, amount_*, method_*, signs_overwater_*, signs_underwater_*, method_note_*, critical_periods_* + watering_method(`drip`), drought_tolerance(`low`), schedule_by_stage (4 entries keyed to establishment/fruit_set/renovation/dormancy). Anchored osu_ext + umn_ext.
- **storage** (register pairs + anchor): room_temp_*, fridge_*, freezer_*, notes_*. Anchored **uc_anr_8256** + osu_ext.
- **yield_expectations** (register pairs + factors): per_plant_*, peak_production_*, first_year_note_* + factors_seasoned (5-item SINGLE-REGISTER; no _beginner twin, intentional SP). Anchored osu_ext + umn_ext.
- **Top-level register pairs:** description_*, harvest_ready_* (+ harvest_ready_sources/anchoring_urls: osu_ext + uc_anr_8256), bloom_time_*, hardiness_notes_*, chill_hours_note_* (N/A PROSE per D8, chill scalars stay null), soil_prep_*.
- **diseases** (was []): 6 entries -- gray mold/Botrytis, anthracnose, powdery mildew, red stele, Verticillium wilt. Shape name/symptoms_*/cause_*/organic_treatment_*/prevention_*/severity/type/audience.
- **pests** (was []): 7 entries -- slugs, spotted wing drosophila, tarnished plant bug, aphids, two-spotted spider mite, root/crown weevils, birds.
- **failure_diagnostics** (was []): 5 entries -- runners_no_fruit, small_misshapen_fruit, gray_fuzz_fruit, no_fruit_year_one, winter_crown_kill. Shape id/label_*/what_happened_*/next_season_tip_*/audience.
- **notifications** (was []): 6 entries -- plant_window, pinch_flowers_y1, frost_on_bloom, harvest_window, renovation_reminder, winter_mulch. Machinery: action/trigger_type/offset_from/offset_days/condition/stage/id.
- **weather_triggers** (was []): 4 entries -- frost_bloom, heat_pause, heavy_rain_harvest, hard_freeze_winter. Machinery: action/severity/condition/id.
- **DEFERRED item 1 (day-neutral type story):** `type_selection_seasoned`/`_beginner` extended (drift-guarded replace, existing text byte-preserved) with the mild-coast near-year-round day-neutral window -- in the TYPE narrative per kickoff, not the region cells.
- **DEFERRED item 2 (ca_interior fall crop):** NO write -- already surfaced in ca_interior `region_notes_seasoned` + the cell `grown_as_note_seasoned` (correct home for a valley-specific detail; a crop-level harvest_ready_* edit would leak a region detail into universal prose). Disposition logged.

### Expected gate movement (Claude Code at release)
- `register_fill_gate strawberry` -> **0** (worklist closed; allowlist = hardiness_zone_max/reliable_fruit_zone_max + hawaii lifecycle, none of which are register fields).
- empty-compound check -> **0** (all 6 arrays populated).
- `register_completeness_gate` -> no unruled/mis-placed prose key (all new keys are CP suffixed-siblings or known machinery/label/SP per Appendix A).
- `whole_crop_gate strawberry` -> stays PASS, incl. the new **D9 `berries_herbaceous_violations`** fill branch (lifecycle fields present; grown_as typed; grown_as<->calendar coherence; no tree keys; self_fertile honored, no bloom_group/pollinizer; photoperiod NOT in gating_factors). No `gating_factors` key added (D7 honored).

### Self-verification done in-lane (claude.ai)
- Drift-guard validation: 0 failures (every replace/delete `from` == slice byte-exact).
- Apply simulation on slice: 0 remaining register nulls; 6/6 compounds populated; untouched blocks byte-identical (collateral clean).
- User-facing dash scan: 0 `--`/em/en across authored prose. "degrees F" text: 0 (normalization pass -> `°F` symbol, 10 strings).
- Dual-register: 143 distinct pairs; 1 allowed self-identical label (`failure_diagnostics` gray-fuzz label, no jargon to simplify).
- Verbatim 8-gram scan vs fetched sources: 3 hits, all irreducible numeric specs ("1 to 1.5 inches of water per week", "7 to 15 pounds per 10 foot row") inside reworded sentences -- the 21-0-0/standard-unit pattern, logged not rewritten.
- Numeric fidelity: every figure cross-checked vs EC1307 / UC ANR 8256.

### Path manifest (76 ops) -- for the claim cross-check
growth_stages; fertilizer.{frequency,type,timing,example_product,notify_days_after,stage_id,notes_*,notify_message_*,npk_hint_*,amount_*,sources,anchoring_urls}; watering.{frequency_*,amount_*,method_*,signs_overwater_*,signs_underwater_*,watering_method,drought_tolerance,method_note_*,critical_periods_*,schedule_by_stage,sources,anchoring_urls}; storage.{room_temp_*,fridge_*,freezer_*,notes_*,sources,anchoring_urls}; yield_expectations.{per_plant_*,peak_production_*,first_year_note_*,factors_seasoned,sources,anchoring_urls}; description_*; harvest_ready_* (+ harvest_ready_sources, harvest_ready_anchoring_urls); bloom_time_*; hardiness_notes_*; chill_hours_note_*; soil_prep_*; diseases; pests; failure_diagnostics; notifications; weather_triggers; type_selection_seasoned; type_selection_beginner.
