# Strawberry Steps 6-8 -- source-mint flag + open findings (handback)

## SOURCE TO MINT (Claude Code lane, at release)
- **`uc_anr_8256`** -- UC ANR Publication 8256, "Strawberries: Safe Methods to Store, Preserve, and Enjoy" (Harris, L. J., 2007). DOI 10.3733/ucanr.8256.
  - URL (anchoring): `https://anrcatalog.ucanr.edu/pdf/8256.pdf` (verified present in catalog 2026-06-18; mirror `https://escholarship.org/uc/item/5pw3p4tq`).
  - source_class: `university_extension` (UC ANR). Publisher: University of California Agriculture and Natural Resources.
  - Used to anchor: `storage` (with osu_ext) and `harvest_ready_*` (with osu_ext).
  - Add to `sources_summary.primary[]` mirroring the existing entries' shape.

## OPEN FINDINGS (all `blocks_launch: false`)

1. **`uc_anr_8256` body not machine-fetchable this session** (the microgreens `umn_not_fetched` pattern).
   - The 8256 PDF body is JS/PDF-gated (direct `anrcatalog.ucanr.edu/pdf/8256.pdf` returned 404 on PDF-extract; eScholarship mirror returned an empty JS shell). Storage facts (humidity 90-95%, crisper drawer, closed clamshell / partially-open bag, do-not-wash-until-use, <=7 days fridge under optimum conditions, freeze up to ~1 year, cool berries ASAP after harvest) were captured from search-result snippets + the ANR catalog listing, and are **corroborated by the fully-fetched EC1307** (osu_ext) harvest-and-store section, which is the co-anchor on both storage and harvest_ready.
   - `blocks_launch: false`. Disposition: Step 11 source-fidelity fetch should re-attempt a clean 8256 fetch; if still gated, the EC1307 corroboration stands and the finding closes as the established pattern.

2. **Verbatim numeric-spec runs (3) -- not lifts, logged for the record.**
   - 8-gram scan vs sources surfaced 3 shared runs, all irreducible numeric specifications inside fully-reworded sentences: "1 to 1.5 inches of water per week" and "7 to 15 pounds per 10 foot row" (EC1307). These are the `21-0-0`/standard-unit pattern -- the number + unit IS the citable fact and has no non-identical rendering that preserves accuracy. Surrounding prose is reworded (verified side-by-side). `blocks_launch: false`. No rewrite (rewriting the figures would reduce fidelity).

3. **Pre-existing `type_selection_seasoned` "degrees" (no `°F` symbol) -- OBSERVATION, out of 6-8 scope.**
   - The existing (do-not-touch) `type_selection_seasoned` contains "between about 40 and 90 degrees" -- "degrees" as a word, no `°F` symbol. This is pre-existing authored prose on the "already done" list; per the standing convention there is **no retroactive normalization unless Trevor asks**. My deferred-item-1 edit appended to this field with a drift-guarded replace and **preserved the existing text byte-exact** (did not normalize it). Flagged so the **Step 9 dash/temp sweep** catches it deliberately (it is a genuine user-facing `°F`-convention deviation, just not mine to silently change). NOT a blocker.
   - (My own authored prose uses the `°F` symbol throughout -- 0 "degrees F" text.)

## CARRY-FORWARD (NOT 6-8 work -- Trevor's calls at Step 5 / cert)
- **Boundary scalars** `hardiness_zone_max` / `reliable_fruit_zone_max` -- Option-1 lean, decided once at Step 5. Not stretched here. (Live values: hardiness 3/10, reliable_fruit 4/9 -- the max ends are the Step-5 decision.)
- **hawaii_tropical lifecycle open finding** -- z11 cell resolved `grown_as: perennial` (cool-elevation niche, fall-set short-lived perennial). Confirm/soften at Step 5; carries into the Step 11 open_findings set.

## OPEN QUESTION for Claude Code (schema-renderer confirm)
- `notifications` entries use `trigger_type: "stage"` with `offset_from: null` + `offset_days: null` (stage-anchored, no calendar offset) for plant_window / pinch_flowers_y1 / harvest_window / renovation_reminder / winter_mulch; `frost_on_bloom` uses `trigger_type: "weather"` + `condition: "FROST_DURING_BLOOM"`. Confirm the renderer accepts `stage`-type triggers with null calendar offsets (the perennial arc has no day-from-sow anchor). If the renderer requires a non-null offset, the stage ids are present to derive one.
