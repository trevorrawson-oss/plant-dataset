# strawberry Step 4 SCALE-UP -- author-lane handoff bundle

**Session:** `strawberry_step4_scaleup` (author lane, claude.ai) -- 2026-06-18
**What this is:** the JSON Patch + findings + state snippet filling the LAST 7 warm regions (11 cells) of strawberry's region layer. This is anchor 13, the only `berries_herbaceous` crop. After Claude Code releases this, region fill is **10/10** and `whole_crop_gate` A2 region-fill gaps go to **0**.

**Start SHA (gate on it):** `78ebccffe5a50293799ec5fd5f3c1f44492076dc8640d9117e89da5167476255` (`strawberry_step4_fl_peninsula`)

> This is an AUTHOR-LANE handoff, not a canonical-file promotion. `dataset_update/` carries the **patch + post-apply slice**, not a re-serialized full `crops_data_final.json` -- Claude Code applies the 225 from-guarded ops against canonical under the SHA gate, derives `calendar[]`, mints source IDs, reconciles frost, and pins the real end SHA. The lanes never merge.

## Contents
- **`dataset_update/`**
  - `strawberry_step4_patch.json` -- THE DELIVERABLE. 225 ops + 225 from_guards, RFC-6901 over `/regions`.
  - `strawberry_slice_AFTER.json` -- post-apply slice (calendar[] still empty), structural cross-check for the apply step.
  - `build_patch.py` -- the author-lane builder (emits + self-verifies the patch). Re-runnable against the uploaded slice.
  - `LATEST.txt` -- the CURRENT pointer (`78ebccff`); Claude Code re-pins the end SHA at release.
- **`1_for_project_knowledge/`**
  - `strawberry_step4_scaleup_findings.md` -- the durable findings: 7-region source table, the two surfaced decisions, anchoring + new source IDs, release flags, self-verification, what's next.
- **`2_for_next_chat/`** (Claude Code release session)
  - `00_RELEASE_KICKOFF.md` -- step-by-step release instructions (apply -> mint -> derive -> frost-reconcile -> orphan-key disposition -> gates -> re-pin + commit).
  - `strawberry_step4_patch.json` -- the patch (same file, co-located for the release session).
  - `STATE_HISTORY_snippet.md` -- the append-only entry to add to the top of the `STATE_HISTORY.md` stack.
- **`3_for_your_records/`**
  - `strawberry_step4_scaleup_findings.md` + `STATE_HISTORY_snippet.md` -- records mirror.

## Two decisions surfaced for your ratification (genuine divergences from the kickoff sketch)
- **Decision A -- `warm_arid` (z8) is PERENNIAL, not annual.** The kickoff grouped it with the interior-desert annual template; the correct z8 authority NMSU H-324 grows it as a spring-planted perennial matted row (AZ1667 corroborates: above 3,000 ft = spring-plant perennial). It is the ONLY new cell on the perennial frost-relative shape and the ONLY frost-anchored new cell. **Authored as perennial.** Re-litigate before promotion if you disagree.
- **Decision B -- `hawaii_tropical` (z11) is the WEAKEST of the 7 calls.** Authored PERENNIAL, NOT year_round (the onion hawaii lesson). No clean CTAHR home-garden lifecycle statement exists -- the perennial read is inferred from the cool-elevation niche + frost-free conditions. **Logged as the residual Step-5 open finding (`blocks_launch:false`)**; confirm against a dedicated CTAHR strawberry publication or soften to an informational note at Step 5.

## Self-verification done (author lane, re-run clean this session against the uploaded slice)
225 ops apply under a content-SHA gate, 0 guard failures. All 11 cells filled, `calendar[]` empty on all 11. Shapes correct: 5 annual cells track=annual + resolved_from=null; warm_arid perennial + resolved_from=populated; hawaii perennial + resolved_from=null. Collateral: the 3 filled proof cells + all non-`regions` crop keys byte-identical. Anchoring parity: every cell + arm `anchoring_urls` == `sources`, 0 mismatches. Key-set parity vs filled refs: clean (only extras = the 3 pre-existing orphan null region-root keys, documented as release flag #5, NOT introduced here). User-facing copy: 0 em/en-dash, 0 `--`, 0 bare "degrees F", 0 stray degree symbols, 0 non-US spelling; "degrees Fahrenheit" spelled out throughout (the 7 `--` are confined to backend `plantings_provenance`, allowed by convention).

## Promotion path
1. **You ratify** Decision A + Decision B (or flag either to re-litigate).
2. **You promote manually** (the verification checkpoint): unzip, move into the project, hand `2_for_next_chat/` to the Claude Code release session.
3. **Claude Code releases** per `00_RELEASE_KICKOFF.md` -> region fill 10/10.
4. **Then Step 5** (source fidelity + the once-global boundary-scalar decision + resolve the hawaii open finding) -> Steps 6-8 -> Step 9 -> Step 11 cert + the flip.
