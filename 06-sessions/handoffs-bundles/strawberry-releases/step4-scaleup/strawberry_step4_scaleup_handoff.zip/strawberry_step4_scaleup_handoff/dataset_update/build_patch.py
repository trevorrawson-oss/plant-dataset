#!/usr/bin/env python3
"""
Strawberry Step 4 SCALE-UP -- build the canonical JSON Patch filling the final 7 warm regions
(11 cells). Author lane (claude.ai). calendar[] left [] for the Claude Code deriver.

Every op carries a `from`-guard (RFC-6901 + drift guard). The patch is applied to a copy of
the slice under a content-SHA gate, then independently re-verified.

A5 discipline: each region's grown_as + windows are an independent SOURCE finding. No templating.
  - low_desert_az (z9), ca_desert (z9,10): annual, fall-plant PULLED -- UA AZ1667
  - warm_arid (z8): PERENNIAL spring-plant matted row -- NMSU H-324 (overturns the kickoff sketch)
  - ca_north_coast / ca_south_coast (z9,10): annual, coastal fall-plant winter-production -- UC MG M&SC + UC IPM
  - se_gulf (z8,9): annual, fall-plant PULLED -- LSU AgCenter Pub 3363/3364
  - hawaii_tropical (z11): PERENNIAL elevation/niche, NOT year_round -- CTAHR (flagged finding)
"""
import json, hashlib, copy, sys

SLICE = "/mnt/user-data/uploads/strawberry_slice.json"

# ---- anchoring URL leaves (one per source ID, verified today) ----
V = "2026-06-18"
U = {
    "uariz_ext_az1667": {"url": "https://extension.arizona.edu/sites/default/files/2024-08/az1667-2015.pdf", "verified": V},
    "nmsu_ext_h324": {"url": "https://pubs.nmsu.edu/_h/H324/index.html", "verified": V},
    "ucanr_mg_monterey_santacruz": {"url": "https://ucanr.edu/sites/default/files/2018-03/281247.pdf", "verified": V},
    "uc_ipm": {"url": "https://ipm.ucanr.edu/PMG/GARDEN/FRUIT/CULTURAL/strawberrytime.html", "verified": V},
    "lsu_agcenter_3363": {"url": "https://www.lsuagcenter.com/NR/rdonlyres/F364192A-744D-4E43-B95E-E9EBD75CDF4E/100278/Pub3364Strawberries4Cweb.pdf", "verified": V},
    "ctahr_hawaii_county": {"url": "https://www.ctahr.hawaii.edu/hawaii/Plants.aspx", "verified": V},
}
def anc(*ids):
    return {i: U[i] for i in ids}

ops = []
def add_set(path, value, guard):
    """Emit a `replace` (the slot exists with a null/empty/default value) with a from-guard."""
    ops.append({"op": "replace", "path": path, "from_guard": guard, "value": value})

# ============================================================================================
# Helper to author one ANNUAL region (fall-plant; resolved_from null; season_over emerges)
# ============================================================================================
def annual_region(rid, region_id, region_label, zone_span, region_sources,
                  arm_plant, arm_bloom, arm_hstart, arm_hend,
                  provenance, region_notes_seasoned, region_notes_beginner, cells):
    base = f"/regions/{rid}"
    # region-root metadata
    add_set(f"{base}/region_id", region_id, None)
    add_set(f"{base}/region_label", region_label, None)
    add_set(f"{base}/zone_span", zone_span, [])
    add_set(f"{base}/sources", region_sources, [])
    # plantings[0]: flip track perennial->annual, set establishment arms
    add_set(f"{base}/plantings/0/track", "annual", "perennial")
    add_set(f"{base}/plantings/0/plant_out", [arm_plant], [])
    add_set(f"{base}/plantings/0/bloom", [arm_bloom], [])
    add_set(f"{base}/plantings/0/harvest_start", [arm_hstart], [])
    add_set(f"{base}/plantings/0/harvest_end", [arm_hend], [])
    # region notes + provenance
    add_set(f"{base}/region_notes_seasoned", region_notes_seasoned, None)
    add_set(f"{base}/region_notes_beginner", region_notes_beginner, None)
    add_set(f"{base}/plantings_provenance", provenance, None)
    # per-zone cells
    for z, c in cells.items():
        zb = f"{base}/resolved_by_zone/{z}"
        add_set(f"{zb}/plant_out", c["plant_out"], None)
        add_set(f"{zb}/resolution_method", c["resolution_method"], None)
        add_set(f"{zb}/grown_as", "annual", None)
        add_set(f"{zb}/grown_as_note_seasoned", c["gas"], None)
        add_set(f"{zb}/grown_as_note_beginner", c["gab"], None)
        add_set(f"{zb}/bloom", c["bloom"], None)
        add_set(f"{zb}/harvest_start", c["harvest_start"], None)
        add_set(f"{zb}/harvest_end", c["harvest_end"], None)
        add_set(f"{zb}/harvest", c["harvest"], None)
        add_set(f"{zb}/frost_risk_note_seasoned", c["frn"], None)
        add_set(f"{zb}/resolved_from", None, {})   # null forced by month-resolution (not frost-anchored)
        add_set(f"{zb}/sources", c["sources"], [])
        add_set(f"{zb}/anchoring_urls", c["anc"], {})
        # calendar[] left [] for deriver -- no op (already [])

# ============================================================================================
# Helper to author one PERENNIAL region (frost-relative; resolved_from populated; dormant cycle)
# ============================================================================================
def perennial_region(rid, region_id, region_label, zone_span, region_sources,
                     arm_plant, arm_bloom, arm_hstart, arm_hend,
                     provenance, region_notes_seasoned, region_notes_beginner, cells):
    base = f"/regions/{rid}"
    add_set(f"{base}/region_id", region_id, None)
    add_set(f"{base}/region_label", region_label, None)
    add_set(f"{base}/zone_span", zone_span, [])
    add_set(f"{base}/sources", region_sources, [])
    # plantings[0]: track stays perennial (shell default) -- set arms only
    add_set(f"{base}/plantings/0/plant_out", [arm_plant], [])
    add_set(f"{base}/plantings/0/bloom", [arm_bloom], [])
    add_set(f"{base}/plantings/0/harvest_start", [arm_hstart], [])
    add_set(f"{base}/plantings/0/harvest_end", [arm_hend], [])
    add_set(f"{base}/region_notes_seasoned", region_notes_seasoned, None)
    add_set(f"{base}/region_notes_beginner", region_notes_beginner, None)
    add_set(f"{base}/plantings_provenance", provenance, None)
    for z, c in cells.items():
        zb = f"{base}/resolved_by_zone/{z}"
        add_set(f"{zb}/plant_out", c["plant_out"], None)
        add_set(f"{zb}/resolution_method", c.get("resolution_method", "perennial_herbaceous_precompute"), None)
        add_set(f"{zb}/grown_as", "perennial", None)
        add_set(f"{zb}/grown_as_note_seasoned", c["gas"], None)
        add_set(f"{zb}/grown_as_note_beginner", c["gab"], None)
        add_set(f"{zb}/bloom", c["bloom"], None)
        add_set(f"{zb}/harvest_start", c["harvest_start"], None)
        add_set(f"{zb}/harvest_end", c["harvest_end"], None)
        add_set(f"{zb}/harvest", c["harvest"], None)
        add_set(f"{zb}/frost_risk_note_seasoned", c["frn"], None)
        # frost-bearing perennial cells populate resolved_from; frost-free (hawaii z11) -> null
        add_set(f"{zb}/resolved_from", c.get("resolved_from", None), {})
        add_set(f"{zb}/sources", c["sources"], [])
        add_set(f"{zb}/anchoring_urls", c["anc"], {})

# ============================================================================================
# REGION 1 + 2: HOT LOW DESERTS -- annual fall-plant PULLED (UA AZ1667)
# ============================================================================================
# AZ1667: areas below 3,000 ft -> fall planting Sep 15-Nov 15 (chilled/frigo dormant plants);
# June-bearers fruited the following spring & summer, allowed to fruit one year, replaced the
# following fall; "summer heat causes too much stress." Ideal 55-70 F; afternoon shade essential.
desert_plant_synth = (
    "Set dormant, pre-chilled (frigo) bare-root or plug plants in the fall, from mid September to "
    "mid November, the University of Arizona window for the low desert (below 3,000 feet). "
    "Strawberries are grown here as a cool-season annual, not a perennial bed: plants are set in "
    "fall, fruited the following winter and spring, then pulled before the summer heat, which is "
    "too stressful to carry a planting. This is an absolute, month-resolved window driven by the "
    "low-desert fall-to-spring growing season, not anchored to a last spring frost."
)
desert_bloom_synth = (
    "Flowering builds through the cool winter and into spring once the fall-set plants are "
    "established. Flower buds form under the short days of fall and winter (day lengths under 12 "
    "hours), and the ideal fruiting temperature range is roughly 55 to 70 degrees Fahrenheit."
)
desert_hstart_synth = (
    "Harvest begins in late winter to early spring as temperatures warm into the fruiting range. "
    "In the low desert the first berries typically ripen around March."
)
desert_hend_synth = (
    "Fruiting runs into spring and finishes by about May, after which rising summer heat ends the "
    "season and the planting is pulled and discarded; new plants are set the following fall, since "
    "the heat is too stressful to carry the bed over. The cell harvest window is scoped to this "
    "late-winter-to-spring span."
)

low_desert_az_cells = {
    "9": {
        "plant_out": "mid Sep - mid Nov",
        "resolution_method": "absolute_month_ua_low_desert_guidance",
        "gas": ("Arizona's low desert (below 3,000 feet) grows strawberries as a cool-season annual "
                "rather than a perennial bed. Set dormant, pre-chilled (frigo) plants in fall, from "
                "mid September to mid November, fruit them through winter and spring, then pull and "
                "discard the planting before summer; the intense desert heat is too stressful to carry "
                "a bed over. Establish the bed where it gets morning sun but afternoon shade (a wall, "
                "fence, or 65 percent shade cloth) to reduce heat and water stress, and grow on "
                "well-drained beds because strawberries are sensitive to salty soil and water."),
        "gab": ("In the Arizona low desert, strawberries are a cool-season crop you grow over the "
                "winter, not a bed that lives for years. Plant in fall, pick from late winter into "
                "spring, then pull the plants out before the hot summer and start fresh next fall. "
                "Give them morning sun but shade in the hot afternoon, and grow them where water "
                "drains away well."),
        "bloom": "Jan - Mar",
        "harvest_start": "Mar",
        "harvest_end": "May",
        "harvest": "Mar - May",
        "frn": ("The low desert sees a handful of freezing nights in December and January. Open "
                "blossoms and ripening fruit are damaged below 32 degrees Fahrenheit, so on a night a "
                "freeze is forecast during bloom, cover the bed with frost cloth in the afternoon "
                "beforehand and anchor the edges. Frost pockets where cold air settles are best avoided."),
        "sources": ["uariz_ext_az1667"],
        "anc": anc("uariz_ext_az1667"),
    },
}

ca_desert_cells = {
    "9": {
        "plant_out": "mid Sep - mid Nov",
        "resolution_method": "absolute_month_ua_low_desert_guidance",
        "gas": ("California's low desert (the Coachella and Imperial valleys) shares the Sonoran/Colorado "
                "desert climate, and strawberries are grown there as a cool-season annual, not a "
                "perennial bed. Set dormant, pre-chilled plants in fall, fruit them through winter and "
                "spring, then pull and discard the planting before the summer heat, which is too "
                "stressful to carry a bed over. Use well-drained beds and provide afternoon shade to "
                "reduce heat and water stress; strawberries are sensitive to salts in desert soil and water."),
        "gab": ("In the California low desert, strawberries are a winter crop you grow and then replace, "
                "not a bed that comes back for years. Plant in fall, pick from late winter into spring, "
                "then pull the plants before the brutal summer heat and start over next fall. Shade them "
                "in the hot afternoons and plant where water drains away."),
        "bloom": "Jan - Mar",
        "harvest_start": "Mar",
        "harvest_end": "May",
        "harvest": "Mar - May",
        "frn": ("The low desert can drop below freezing on a few clear winter nights. Open blossoms and "
                "fruit are injured below 32 degrees Fahrenheit, so cover the bed with frost cloth on a "
                "forecast freeze during bloom and anchor the edges."),
        "sources": ["uariz_ext_az1667", "uc_ipm"],
        "anc": anc("uariz_ext_az1667", "uc_ipm"),
    },
    "10": {
        "plant_out": "mid Sep - mid Nov",
        "resolution_method": "absolute_month_ua_low_desert_guidance",
        "gas": ("In the warmest low-desert pockets (zone 10), strawberries are still grown as a "
                "cool-season annual on the same fall-to-spring schedule: set pre-chilled plants in fall, "
                "fruit through winter and spring, then pull before summer. Zone 10 is nearly frost-free, "
                "so the season is bounded by heat rather than cold. Afternoon shade and well-drained, "
                "low-salt beds are essential."),
        "gab": ("In the hottest, nearly frost-free parts of the California low desert, strawberries are "
                "a winter crop. Plant in fall, pick from late winter into spring, then pull the plants "
                "before the summer heat returns and replant next fall. Give them afternoon shade and "
                "good drainage."),
        "bloom": "Dec - Mar",
        "harvest_start": "Feb",
        "harvest_end": "May",
        "harvest": "Feb - May",
        "frn": ("Zone 10 in the low desert is nearly frost-free, so freeze injury to blossoms is rarely "
                "a concern; the season is limited by summer heat, not cold. On a rare radiational freeze, "
                "cover open blossoms with frost cloth as a precaution."),
        "sources": ["uariz_ext_az1667", "uc_ipm"],
        "anc": anc("uariz_ext_az1667", "uc_ipm"),
    },
}

annual_region(
    "low_desert_az", "low_desert_az", "Low Desert (Arizona)", ["9"], ["uariz_ext_az1667"],
    arm_plant={"label": "establishment", "from": None, "window": "mid Sep - mid Nov",
               "synthesis_note": desert_plant_synth, "sources": ["uariz_ext_az1667"],
               "anchoring_urls": anc("uariz_ext_az1667")},
    arm_bloom={"label": "establishment", "from": None, "window": "Jan - Mar",
               "synthesis_note": desert_bloom_synth, "sources": ["uariz_ext_az1667"],
               "anchoring_urls": anc("uariz_ext_az1667")},
    arm_hstart={"label": "establishment", "from": None, "window": "Mar",
                "synthesis_note": desert_hstart_synth, "sources": ["uariz_ext_az1667"],
                "anchoring_urls": anc("uariz_ext_az1667")},
    arm_hend={"label": "establishment", "from": None, "window": "May",
              "synthesis_note": desert_hend_synth, "sources": ["uariz_ext_az1667"],
              "anchoring_urls": anc("uariz_ext_az1667")},
    provenance=("Region-constant cool-season-annual establishment window, month-resolved (absolute), NOT "
                "frost-relative. The Arizona low desert below 3,000 feet (Southern Arizona, Gila and Salt "
                "River valleys) grows June-bearing strawberries as a fall-planted annual (UA AZ1667): "
                "dormant pre-chilled (frigo) plants set mid September to mid November, fruited the "
                "following winter and spring, then PULLED before the summer heat and replanted the next "
                "fall ('the summer heat causes too much stress for strawberries'). This is the desert "
                "fall-plant PULLED sub-shape (season_over emerges for the summer off-season), distinct "
                "from the ca_interior summer-plant CARRIED bed. resolved_from is null per cell, forced by "
                "the heat/season-driven window (z9 carries some winter frost, but the limiter is heat, not "
                "the last spring frost). Windows anchor to UA Cooperative Extension AZ1667 (Growing "
                "Strawberries in Home Gardens). NOTE for Claude Code: calendar[] left [] for the deriver; "
                "this cell is expected to emit season_over. A5: do NOT template the FL fall-plant window or "
                "the ca_interior summer-plant window onto this cell -- the desert window is its own."),
    region_notes_seasoned=(
        "In the Arizona low desert (zone 9, below 3,000 feet), strawberries are grown as a cool-season "
        "annual, not a perennial bed. Set dormant, pre-chilled (frigo) bare-root or plug plants in fall, "
        "from mid September to mid November, so they establish for fruiting the following winter and "
        "spring. Plants are pulled before summer, because desert heat above the ideal 55 to 70 degree "
        "Fahrenheit fruiting range is too stressful to carry a bed over; replant fresh each fall. Grow "
        "where plants get morning sun but afternoon shade from a wall, fence, or 65 percent shade cloth, "
        "and use well-drained beds, since strawberries are highly sensitive to salty soil and water. "
        "A few freezing nights occur in December and January, so keep frost cloth handy to protect open "
        "blossoms below 32 degrees Fahrenheit. Choose low-desert-adapted June-bearers, and avoid planting "
        "where tomatoes, peppers, eggplant, or potatoes recently grew to limit Verticillium wilt."),
    region_notes_beginner=(
        "In the Arizona low desert, strawberries are a winter crop you grow and then replace, not a bed "
        "that lives for years. Plant dormant or young plants in the fall, from about mid September to mid "
        "November, pick berries from late winter into spring, then pull the plants before the hot summer "
        "and plant fresh ones the next fall. Give them morning sun but shade in the hot afternoon, water "
        "regularly because their roots are shallow, and grow them where water drains away well. A few cold "
        "nights in winter can hurt the flowers, so keep a frost cloth ready to cover them."),
    cells=low_desert_az_cells,
)

annual_region(
    "ca_desert", "ca_desert", "California Low Desert", ["9", "10"], ["uariz_ext_az1667", "uc_ipm"],
    arm_plant={"label": "establishment", "from": None, "window": "mid Sep - mid Nov",
               "synthesis_note": desert_plant_synth + " The same low-desert practice applies across "
               "the California desert valleys (Coachella, Imperial), which share the Sonoran/Colorado "
               "desert climate.", "sources": ["uariz_ext_az1667", "uc_ipm"],
               "anchoring_urls": anc("uariz_ext_az1667", "uc_ipm")},
    arm_bloom={"label": "establishment", "from": None, "window": "Dec - Mar",
               "synthesis_note": desert_bloom_synth, "sources": ["uariz_ext_az1667", "uc_ipm"],
               "anchoring_urls": anc("uariz_ext_az1667", "uc_ipm")},
    arm_hstart={"label": "establishment", "from": None, "window": "Feb - Mar",
                "synthesis_note": desert_hstart_synth + " The nearly frost-free zone 10 pockets can "
                "start a few weeks earlier than zone 9.", "sources": ["uariz_ext_az1667", "uc_ipm"],
                "anchoring_urls": anc("uariz_ext_az1667", "uc_ipm")},
    arm_hend={"label": "establishment", "from": None, "window": "May",
              "synthesis_note": desert_hend_synth, "sources": ["uariz_ext_az1667", "uc_ipm"],
              "anchoring_urls": anc("uariz_ext_az1667", "uc_ipm")},
    provenance=("Region-constant cool-season-annual establishment window, month-resolved (absolute), NOT "
                "frost-relative. The California low desert (Coachella and Imperial valleys) shares the "
                "Sonoran/Colorado low-desert climate, and strawberries are grown there as a fall-planted "
                "annual on the same model UA AZ1667 documents for the Arizona low desert: pre-chilled "
                "plants set mid September to mid November, fruited winter into spring, then PULLED before "
                "the summer heat. UC Master Gardener desert-valleys guidance confirms the cool-season "
                "fall-set/spring-crop rhythm for this region (the dated strawberry window itself lives in "
                "the UA low-desert publication, since strawberry is a fruit and is absent from the UC "
                "vegetable planting table -- the lesson zinnia taught). Primary anchor UA AZ1667; UC IPM "
                "cultural-tips corroborates the California cultural practice (afternoon shade, salt "
                "sensitivity, heaviest production timing). resolved_from null per cell (heat/season-driven; "
                "z9 carries winter frost but the limiter is heat). season_over emerges. A5: do NOT lift the "
                "FL or coastal-CA windows here -- the desert window is its own."),
    region_notes_seasoned=(
        "In the California low desert (the Coachella and Imperial valleys, zones 9 and 10), strawberries "
        "are grown as a cool-season annual rather than a perennial bed, the same way they are across the "
        "Sonoran desert. Set dormant, pre-chilled plants in fall, from mid September to mid November, "
        "fruit them through winter and spring, then pull and discard the planting before the summer heat, "
        "which is too stressful to carry a bed over; replant fresh each fall. Provide afternoon shade and "
        "use well-drained, low-salt beds. Zone 9 sees occasional winter frost that can injure open "
        "blossoms below 32 degrees Fahrenheit, so keep frost cloth handy during bloom; the warmest zone "
        "10 pockets are nearly frost-free and can start fruiting a few weeks earlier. Choose "
        "desert-adapted June-bearers and rotate away from recent tomato, pepper, or eggplant beds."),
    region_notes_beginner=(
        "In the California low desert, strawberries are a winter crop you grow and then replace, not a bed "
        "that returns for years. Plant in the fall, from about mid September to mid November, pick berries "
        "from late winter into spring, then pull the plants before the brutal summer heat and plant fresh "
        "ones next fall. Give them shade in the hot afternoons, water often because their roots are "
        "shallow, and plant where water drains away. In the cooler zone 9 areas a winter cold snap can "
        "hurt the flowers, so keep a frost cloth ready."),
    cells=ca_desert_cells,
)

# ============================================================================================
# REGION 3: warm_arid (z8) -- PERENNIAL spring-plant matted row (NMSU H-324)
#   *** OVERTURNS the kickoff "interior deserts on ca_interior annual template" sketch (A5) ***
# ============================================================================================
# NMSU H-324: spring planting after danger of hard frost (cool weather -> survival); June-bearer
# flower buds initiate previous fall (Sep-Nov, short days); bloom early spring; ONE spring crop;
# renovate after harvest (before Jul 15); matted-row beds last 3-4 years; southern NM needs
# afternoon shade. Frost protection for spring blossoms highly recommended. z8 frost: LSpr Feb 15,
# FFall Dec 1 -> frost-relative anchoring (same shape as northern_tier).
warmarid_plant_synth = (
    "Set dormant bare-root crowns in early spring, after the danger of hard frost has passed and as "
    "soon as the soil can be worked. New Mexico State recommends spring planting because the cool "
    "weather gives the plants the best chance to establish. Plant so the middle of the crown is "
    "level with the soil surface. In a matted-row system, space plants about 18 inches apart in rows "
    "36 to 42 inches apart and let runners fill the row to 12 to 18 inches wide; a plastic- or "
    "fabric-covered perennial bed is an alternative for day-neutral types."
)
warmarid_bloom_synth = (
    "On an established bed, June-bearing plants flower in early spring from buds that formed the "
    "previous fall under short days. Those early blossoms produce the largest berries and are "
    "frost-sensitive, so frost protection during bloom is strongly recommended (NMSU)."
)
warmarid_hstart_synth = (
    "The single concentrated June-bearing harvest begins in late spring. In the planting year, "
    "flowers are pinched off so no crop is taken, which strengthens the plants for a full crop the "
    "following spring (year_one_notes)."
)
warmarid_hend_synth = (
    "The spring flush finishes by early summer; matted-row beds are renovated immediately after "
    "harvest (mow old foliage above the crowns, narrow the row, weed, and fertilize), and should not "
    "be renovated after July 15. Beds remain productive for about three to four years before "
    "replanting (NMSU)."
)

warm_arid_cells = {
    "8": {
        "plant_out": "Mar 1 - Mar 22",   # frost-relative: ~2 wk before last frost (Feb 15) + window; deriver re-resolves from offsets
        "gas": ("Interior arid New Mexico and similar high-desert zone 8 areas grow strawberries as a "
                "perennial matted row, planted in early spring after hard frost. June-bearers set flower "
                "buds the previous fall and crop once in late spring; renovate the bed right after harvest "
                "and expect three to four productive years. In the warmer, lower areas, afternoon shade "
                "(a fence, wall, or 65 percent shade cloth) reduces summer heat and water stress, and a "
                "winter straw mulch protects crowns. High-pH desert soils cause iron chlorosis, so choose "
                "tolerant cultivars and treat with iron chelate as needed."),
        "gab": ("In the high desert of New Mexico (zone 8), a strawberry bed comes back each year. Plant "
                "dormant crowns in early spring once hard frost is past, and you will get one big crop in "
                "late spring. After picking, mow and tidy the bed so it stays healthy, and replant every "
                "three to four years. Shade the plants from harsh afternoon sun, mulch with straw over "
                "winter, and watch for yellowing leaves, which iron treatment fixes."),
        "bloom": "Apr - May",
        "harvest_start": "May",
        "harvest_end": "Jun",
        "harvest": "May - Jun",
        "frn": ("Late spring frosts are the main risk: open blossoms in April and May are frost-sensitive "
                "and the earliest blossoms produce the largest berries, so cover the bed with a frost "
                "blanket or straw on frosty nights during bloom. Siting the bed on a gentle slope so cold "
                "air drains away, or using a northern exposure to delay bloom, reduces frost loss."),
        "resolved_from": {"last_frost": "Feb 15", "first_frost": "Dec 1"},
        "sources": ["nmsu_ext_h324"],
        "anc": anc("nmsu_ext_h324"),
    },
}

perennial_region(
    "warm_arid", "warm_arid", "Warm Arid (Interior)", ["8"], ["nmsu_ext_h324"],
    arm_plant={"label": "establishment", "from": "last_frost", "offset_days": -14, "window_days": 21,
               "synthesis_note": warmarid_plant_synth, "sources": ["nmsu_ext_h324"],
               "anchoring_urls": anc("nmsu_ext_h324")},
    arm_bloom={"label": "establishment", "from": "last_frost", "offset_days": 45, "window_days": 30,
               "synthesis_note": warmarid_bloom_synth, "sources": ["nmsu_ext_h324"],
               "anchoring_urls": anc("nmsu_ext_h324")},
    arm_hstart={"label": "establishment", "from": "last_frost", "offset_days": 75,
                "synthesis_note": warmarid_hstart_synth, "sources": ["nmsu_ext_h324"],
                "anchoring_urls": anc("nmsu_ext_h324")},
    arm_hend={"label": "establishment", "from": "last_frost", "offset_days": 110,
              "synthesis_note": warmarid_hend_synth, "sources": ["nmsu_ext_h324"],
              "anchoring_urls": anc("nmsu_ext_h324")},
    provenance=("Region-constant PERENNIAL matted-row establishment, frost-relative (anchored to the last "
                "spring frost), planted in early spring. *** A5 OVERTURN: the kickoff sketch grouped "
                "warm_arid with the 'interior deserts on the ca_interior summer-plant annual template,' but "
                "the z8 interior-arid authority (NMSU H-324, Home Garden Strawberry Production in New Mexico) "
                "grows it as a SPRING-PLANTED PERENNIAL matted row, NOT a pulled or summer-plant annual. ***"
                " NMSU: plant dormant crowns in spring after hard frost; June-bearer flower buds initiate the "
                "previous fall under short days; one concentrated late-spring crop; renovate immediately "
                "after harvest (before Jul 15); beds last 3-4 years; southern/warmer NM needs afternoon "
                "shade and high-pH iron management. AZ1667 independently corroborates that Arizona areas "
                "ABOVE 3,000 feet are spring-planted perennials (3-4 fruiting years, runners, renovation) -- "
                "the same elevation/climate class as z8 warm_arid, distinct from the below-3,000-ft low "
                "desert. This is the SAME perennial frost-relative shape as northern_tier (dormant + bloom + "
                "harvest + renovation; NO season_over). z8 carries frost (zone_frost_data: last_spring Feb 15, "
                "first_fall Dec 1), so the cell frost-anchors -- resolved_from POPULATED. NOTE for Claude "
                "Code: calendar[] left [] for the deriver (perennial cycle, NO season_over); reconcile the "
                "z8 resolved_from against zone_frost_data and re-derive the offsets. A5: do NOT import the "
                "low-desert fall-plant window here."),
    region_notes_seasoned=(
        "In interior arid zone 8 (the New Mexico high desert and similar areas), strawberries are grown as "
        "a perennial matted row, not a pulled annual. Plant dormant bare-root crowns in early spring, after "
        "the danger of hard frost and as soon as the soil can be worked, spacing plants about 18 inches "
        "apart in rows 36 to 42 inches apart and letting runners fill the row. June-bearing plants set "
        "their flower buds the previous fall under short days and give one concentrated crop in late "
        "spring; pinch off all flowers the first year to build strong plants. Renovate the bed right after "
        "harvest (mow the old foliage above the crowns, narrow the row, weed, and fertilize) and expect "
        "about three to four productive years before replanting. In warmer, lower spots, afternoon shade "
        "reduces summer heat and water stress. High-pH desert soils cause iron chlorosis, so choose "
        "tolerant cultivars and apply an iron chelate when leaves yellow. Late spring frosts are the main "
        "threat to the crop, so protect open blossoms, and mulch crowns with straw over winter."),
    region_notes_beginner=(
        "In the high desert of zone 8, a strawberry bed comes back year after year. Plant dormant crowns in "
        "early spring once hard frost is past, and pinch off the flowers that first year so the plants grow "
        "strong. From the second spring on you get one big crop in late spring. After picking, mow and tidy "
        "the bed to keep it healthy, and start a new bed every three to four years. Shade the plants from "
        "harsh afternoon sun, cover them with straw over winter, and protect the flowers on frosty spring "
        "nights. If the leaves turn yellow, an iron treatment usually fixes it."),
    cells=warm_arid_cells,
)

# ============================================================================================
# REGION 4 + 5: COASTAL CALIFORNIA -- annual fall-plant winter-production (UC MG M&SC + UC IPM)
#   The genuine perennial-vs-annual fork: source resolves to the ANNUAL fall-plant system.
# ============================================================================================
# UC MG Monterey & Santa Cruz: mid-to-late Aug best in all locations; short-day summer Aug 15-Sep 5,
# winter Oct 15-Nov 5; day-neutral summer Sep 25-Oct 10, winter Oct 25-Nov 26. Fruit production
# highest the first full season then declines (replant). UC IPM cultural-tips: heaviest production
# May-June for both types. The home-garden default is the fall-plant winter-production annual.
coast_plant_synth = (
    "Set transplants from mid August into fall, the UC window for the California coast; mid to late "
    "August is a good time in all coastal locations, and day-neutral types can also go in during the "
    "fall. Strawberries are grown on the mild coast as a fall-planted annual system: fruit production "
    "is highest in the first full season after planting and then declines, so the bed is replaced "
    "rather than carried for years. Space plants about 12 inches apart in two-row beds. This is an "
    "absolute, month-resolved window driven by the mild coastal season, not anchored to a last "
    "spring frost."
)
coast_bloom_synth = (
    "Flowering builds from late winter into spring on the mild coast. Short-day types flower as the "
    "cool, short days of late winter give way to spring; day-neutral types flower across a longer "
    "span. The cool, foggy coastal climate suits berries well, with little heat stress on fruit set."
)
coast_hstart_synth = (
    "Harvest begins in spring and builds toward the heaviest production in May and June (UC IPM: "
    "heaviest production for both short-day and day-neutral plantings is in May and June)."
)
coast_hend_synth = (
    "On the mild coast, harvest of day-neutral plantings can extend through summer into fall, but the "
    "main flush ends by midsummer and production declines after the first full season, so beds are "
    "typically replaced. The cell harvest window is scoped to the main spring-to-early-summer flush."
)

ca_north_coast_cells = {
    "9": {
        "plant_out": "mid Aug - early Nov",
        "resolution_method": "absolute_month_uc_coastal_planting_dates",
        "gas": ("The cool, foggy north and central coast grows strawberries as a fall-planted annual "
                "system rather than a long-lived perennial bed. Set short-day (June-bearing) transplants "
                "from mid August to early September, or in the fall, and day-neutral types from late "
                "September into November; production peaks the first full spring and then declines, so "
                "replace the bed rather than carrying it for years. The mild climate means little heat "
                "stress, and day-neutral varieties can fruit across much of the year here."),
        "gab": ("On the cool, foggy coast, strawberries grow best when you plant them in late summer or "
                "fall and replace them rather than keeping the same bed for years. Plant transplants from "
                "about mid August into fall, and you will get the most berries the following spring. The "
                "mild weather is easy on the plants, and some types keep fruiting much of the year."),
        "bloom": "Feb - Apr",
        "harvest_start": "Apr",
        "harvest_end": "Jul",
        "harvest": "Apr - Jul",
        "frn": ("The mild coast rarely sees a hard freeze, but an inland cold pocket or an early cold "
                "snap can nip open blossoms, which are damaged below 32 degrees Fahrenheit. On a forecast "
                "frosty night during bloom, cover the bed with frost cloth."),
        "sources": ["ucanr_mg_monterey_santacruz", "uc_ipm"],
        "anc": anc("ucanr_mg_monterey_santacruz", "uc_ipm"),
    },
    "10": {
        "plant_out": "mid Aug - early Nov",
        "resolution_method": "absolute_month_uc_coastal_planting_dates",
        "gas": ("The warmest north-coast pockets (zone 10) grow strawberries on the same fall-planted "
                "annual system: set transplants from mid August into fall, take the main crop the "
                "following spring, and replace the bed as production declines. Zone 10 here is essentially "
                "frost-free, so the season is bounded by the mild climate rather than cold, and day-neutral "
                "types can fruit across much of the year."),
        "gab": ("In the mildest, nearly frost-free coastal spots, strawberries are still best planted in "
                "late summer or fall and replaced rather than kept for years. Plant from about mid August "
                "into fall for the biggest crop the next spring. With no real frost, some types keep "
                "producing much of the year."),
        "bloom": "Jan - Apr",
        "harvest_start": "Mar",
        "harvest_end": "Jul",
        "harvest": "Mar - Jul",
        "frn": ("These mild coastal zone 10 areas are essentially frost-free, so freeze injury to "
                "blossoms is rarely a concern; the season is shaped by the cool maritime climate rather "
                "than cold."),
        "sources": ["ucanr_mg_monterey_santacruz", "uc_ipm"],
        "anc": anc("ucanr_mg_monterey_santacruz", "uc_ipm"),
    },
}

ca_south_coast_cells = {
    "9": {
        "plant_out": "mid Aug - Nov",
        "resolution_method": "absolute_month_uc_coastal_planting_dates",
        "gas": ("The mild south coast (San Luis Obispo south through Oxnard and the South Coast) grows "
                "strawberries as a fall-planted annual system, the heart of California's coastal "
                "winter-planting model. Set short-day transplants from mid August through fall and "
                "day-neutral types into late fall; in the warmest south-coast districts, fall-set plants "
                "begin fruiting in winter and run into summer, with production peaking the first full "
                "season, then the bed is replaced. The mild climate carries little heat stress."),
        "gab": ("On the mild south coast, strawberries grow best planted in late summer or fall and then "
                "replaced rather than kept for years. Plant transplants from about mid August into fall; "
                "in the warmest spots they start fruiting in winter and keep going into summer, with the "
                "biggest crop the first full season."),
        "bloom": "Jan - Apr",
        "harvest_start": "Feb",
        "harvest_end": "Jul",
        "harvest": "Feb - Jul",
        "frn": ("The south coast rarely freezes, but an inland cold pocket can nip open blossoms below 32 "
                "degrees Fahrenheit; cover the bed on a forecast frosty night during bloom. Most coastal "
                "south-coast gardens see little to no frost."),
        "sources": ["ucanr_mg_monterey_santacruz", "uc_ipm"],
        "anc": anc("ucanr_mg_monterey_santacruz", "uc_ipm"),
    },
    "10": {
        "plant_out": "mid Aug - Nov",
        "resolution_method": "absolute_month_uc_coastal_planting_dates",
        "gas": ("The warmest, frost-free south-coast pockets (zone 10) grow strawberries on the same "
                "fall-planted annual system: set transplants from mid August into late fall, with "
                "fall-set plants fruiting from winter into summer and the heaviest production in the first "
                "full season before the bed is replaced. With essentially no frost, day-neutral types can "
                "fruit across much of the year."),
        "gab": ("In the mildest, frost-free parts of the south coast, plant strawberries in late summer or "
                "fall and replace them rather than keeping them for years. Fall-planted beds fruit from "
                "winter into summer, and with no frost some types keep producing much of the year."),
        "bloom": "Dec - Apr",
        "harvest_start": "Jan",
        "harvest_end": "Jul",
        "harvest": "Jan - Jul",
        "frn": ("Zone 10 on the south coast is essentially frost-free, so freeze injury to blossoms is "
                "rarely a concern; the mild maritime climate, not cold, shapes the season."),
        "sources": ["ucanr_mg_monterey_santacruz", "uc_ipm"],
        "anc": anc("ucanr_mg_monterey_santacruz", "uc_ipm"),
    },
}

annual_region(
    "ca_north_coast", "ca_north_coast", "California North & Central Coast", ["9", "10"],
    ["ucanr_mg_monterey_santacruz", "uc_ipm"],
    arm_plant={"label": "establishment", "from": None, "window": "mid Aug - early Nov",
               "synthesis_note": coast_plant_synth, "sources": ["ucanr_mg_monterey_santacruz"],
               "anchoring_urls": anc("ucanr_mg_monterey_santacruz")},
    arm_bloom={"label": "establishment", "from": None, "window": "Feb - Apr",
               "synthesis_note": coast_bloom_synth, "sources": ["ucanr_mg_monterey_santacruz", "uc_ipm"],
               "anchoring_urls": anc("ucanr_mg_monterey_santacruz", "uc_ipm")},
    arm_hstart={"label": "establishment", "from": None, "window": "Apr",
                "synthesis_note": coast_hstart_synth, "sources": ["uc_ipm"],
                "anchoring_urls": anc("uc_ipm")},
    arm_hend={"label": "establishment", "from": None, "window": "Jul",
              "synthesis_note": coast_hend_synth, "sources": ["ucanr_mg_monterey_santacruz", "uc_ipm"],
              "anchoring_urls": anc("ucanr_mg_monterey_santacruz", "uc_ipm")},
    provenance=("Region-constant fall-plant winter-production ANNUAL establishment window, month-resolved "
                "(absolute), NOT frost-relative. The genuine perennial-vs-annual coastal fork (flagged in "
                "the kickoff) resolves to the ANNUAL fall-plant system: the UC Master Gardeners of Monterey "
                "& Santa Cruz guide gives dated coastal planting windows (short-day summer Aug 15-Sep 5 / "
                "winter Oct 15-Nov 5; day-neutral summer Sep 25-Oct 10 / winter Oct 25-Nov 26; 'middle to "
                "late August generally is the best time to plant in all locations') and states production is "
                "highest the first full season then declines -> the bed is replaced, not carried. This is "
                "the California coastal fall-plant winter-production model (the Fronteras variety note: "
                "'adapted to the fall planting and winter production system of the California coast'). "
                "Distinct from the desert (pulled at summer onset by heat) and the interior (summer-plant). "
                "Cell-level harvest timing anchored to UC IPM cultural-tips ('heaviest production in May and "
                "June' for both types) -- the same cell anchor ca_interior uses. resolved_from null per cell "
                "(mild/season-driven; z9 carries nominal frost but the limiter is the mild season, not the "
                "last spring frost). NOTE for Claude Code: calendar[] left []; the fall-to-summer windows "
                "WRAP without a clean no-plant summer gap on the mild coast, so the deriver may NOT emit "
                "season_over here (carried-vs-pulled is emergent) -- verify the deriver's branch on this "
                "cell. The day-neutral near-year-round type story stays in the centralized type_selection_* "
                "(Steps 6-8), not the cell. A5: do NOT lift the desert or interior windows."),
    region_notes_seasoned=(
        "On California's cool, foggy north and central coast (zones 9 and 10, Monterey County north), "
        "strawberries are grown as a fall-planted annual system rather than a long-lived perennial bed. "
        "Set short-day (June-bearing) transplants from mid August to early September, or in the fall, and "
        "day-neutral types from late September into November; mid to late August is a good planting time in "
        "all coastal locations. Production is highest in the first full season after planting and declines "
        "after that, so replace the bed rather than carrying it for years. The cool maritime climate puts "
        "little heat stress on fruit set, the main flush builds to heaviest production in May and June, and "
        "day-neutral varieties can fruit across much of the year on the mild coast. Hard frost is rare, but "
        "protect open blossoms in any inland cold pocket. Grow on raised, well-drained beds and keep "
        "moisture off the flowers to limit fruit rot in the damp coastal air."),
    region_notes_beginner=(
        "On the cool, foggy California coast, strawberries grow best when you plant them in late summer or "
        "fall and replace them rather than keeping the same bed for years. Plant transplants from about mid "
        "August into fall, and you will pick the most berries the following spring, with the heaviest "
        "picking in May and June. The mild weather is easy on the plants, and some types keep fruiting much "
        "of the year. Grow them on raised beds so water drains away, and try to keep the leaves and flowers "
        "dry to avoid rot. Hard frost is rare here, but cover the flowers if a cold night is forecast inland."),
    cells=ca_north_coast_cells,
)

annual_region(
    "ca_south_coast", "ca_south_coast", "California South Coast", ["9", "10"],
    ["ucanr_mg_monterey_santacruz", "uc_ipm"],
    arm_plant={"label": "establishment", "from": None, "window": "mid Aug - Nov",
               "synthesis_note": coast_plant_synth + " On the warmest south coast, fall-set plants can "
               "begin fruiting in winter and run into summer.", "sources": ["ucanr_mg_monterey_santacruz"],
               "anchoring_urls": anc("ucanr_mg_monterey_santacruz")},
    arm_bloom={"label": "establishment", "from": None, "window": "Jan - Apr",
               "synthesis_note": coast_bloom_synth + " On the warm south coast, bloom can begin in midwinter.",
               "sources": ["ucanr_mg_monterey_santacruz", "uc_ipm"],
               "anchoring_urls": anc("ucanr_mg_monterey_santacruz", "uc_ipm")},
    arm_hstart={"label": "establishment", "from": None, "window": "Jan - Feb",
                "synthesis_note": coast_hstart_synth + " In the warmest south-coast districts (the Oxnard/"
                "Ventura pattern), fall-set plants begin fruiting as early as midwinter.",
                "sources": ["ucanr_mg_monterey_santacruz", "uc_ipm"],
                "anchoring_urls": anc("ucanr_mg_monterey_santacruz", "uc_ipm")},
    arm_hend={"label": "establishment", "from": None, "window": "Jul",
              "synthesis_note": coast_hend_synth, "sources": ["ucanr_mg_monterey_santacruz", "uc_ipm"],
              "anchoring_urls": anc("ucanr_mg_monterey_santacruz", "uc_ipm")},
    provenance=("Region-constant fall-plant winter-production ANNUAL establishment window, month-resolved "
                "(absolute), NOT frost-relative. The perennial-vs-annual coastal fork resolves to the ANNUAL "
                "fall-plant system, same as ca_north_coast, anchored to the UC Master Gardeners of Monterey "
                "& Santa Cruz coastal planting dates and UC IPM cultural-tips. The south coast (San Luis "
                "Obispo south, per the UC region split) runs a slightly earlier/longer production tail than "
                "the central coast: in the warmest south-coast districts fall-set plants fruit from "
                "midwinter into summer (the Oxnard/Ventura commercial pattern), with heaviest production "
                "still May-June and the first-season peak followed by replacement. resolved_from null per "
                "cell (mild/season-driven). NOTE for Claude Code: calendar[] left []; windows wrap without a "
                "clean summer no-plant gap -> the deriver may NOT emit season_over (verify the branch). A5: "
                "authored as its own south-coast window, NOT a copy of the central-coast cell -- the "
                "production tail is earlier here; do NOT lift the desert or interior windows."),
    region_notes_seasoned=(
        "On California's mild south coast (zones 9 and 10, San Luis Obispo south through Oxnard and the "
        "South Coast), strawberries are grown as a fall-planted annual system, the heart of the state's "
        "coastal winter-planting model. Set short-day transplants from mid August through fall and "
        "day-neutral types into late fall; in the warmest south-coast districts, fall-set plants begin "
        "fruiting in winter and run into summer, with production peaking the first full season before the "
        "bed is replaced. The mild climate carries little heat stress, the heaviest production falls in May "
        "and June, and day-neutral types can fruit across much of the year. Hard frost is rare on the coast "
        "but possible in inland pockets, so protect open blossoms there. Grow on raised, well-drained beds "
        "and keep moisture off flowers and fruit."),
    region_notes_beginner=(
        "On the mild south coast, strawberries grow best planted in late summer or fall and then replaced "
        "rather than kept for years. Plant transplants from about mid August into fall; in the warmest "
        "spots they start fruiting in winter and keep going into summer, with the biggest crop the first "
        "full season. The mild weather is easy on the plants, and some types fruit much of the year. Grow "
        "them on raised beds for good drainage, keep the flowers dry, and cover them on the rare frosty "
        "night inland."),
    cells=ca_south_coast_cells,
)

# ============================================================================================
# REGION 6: se_gulf (z8, z9) -- annual fall-plant PULLED (LSU AgCenter Pub 3363/3364)
# ============================================================================================
# LSU: plant early Oct - mid Nov; production from late Nov (plugs) through early June; short-day
# flower init in cool fall/winter; remove plants in early summer (humid-summer disease), replant
# next fall; raised rows/plastic/pine straw; flowers die <32F (plants hardy to 17F).
gulf_plant_synth = (
    "Set bare-root or plug transplants in the fall, from early October through mid November, the LSU "
    "AgCenter window for the Gulf Coast (mid to late October is ideal in southeast Louisiana). "
    "Strawberries are grown here as a fall-planted annual: plants are set in fall, fruited through "
    "winter and spring, then removed in early summer because humid-summer disease pressure is "
    "extreme; fresh plants are set the following fall. Grow on raised rows with plastic mulch or a "
    "thick pine-straw layer for drainage and clean fruit. This is an absolute, month-resolved window "
    "driven by the cool fall-to-spring season, not anchored to a last spring frost."
)
gulf_bloom_synth = (
    "Short-day varieties initiate flowers during the short days and cool temperatures of fall and "
    "winter, and fruit appears in late winter and early spring when conditions favor good-quality "
    "berries. Open flowers are damaged below 32 degrees Fahrenheit even though the plants themselves "
    "are cold-hardy."
)
gulf_hstart_synth = (
    "Production can begin as early as late November when plug plants are used, with the harvest "
    "running through winter and building in spring. Louisiana berries appear as early as November, "
    "December, and January."
)
gulf_hend_synth = (
    "Fruiting continues into spring and can run to the beginning of June; after June the plants stop "
    "fruiting and turn to vegetative growth, so the planting is removed in early summer and replaced "
    "the following fall (the nine-month strawberry season). The cell harvest window is scoped to this "
    "late-fall-to-spring span."
)

se_gulf_cells = {
    "8": {
        "plant_out": "early Oct - mid Nov",
        "resolution_method": "absolute_month_lsu_planting_dates",
        "gas": ("The Gulf Coast grows strawberries as a fall-planted annual, not a perennial bed. Set "
                "transplants from early October through mid November, fruit them from late fall into "
                "spring, then remove the planting in early summer because humid-summer disease pressure is "
                "severe, and replant fresh each fall. Grow on raised rows with plastic mulch or a thick "
                "pine-straw layer to keep the heavy rains drained and the fruit clean. Choose short-day "
                "varieties suited to the South."),
        "gab": ("On the Gulf Coast, strawberries are a cool-season crop you grow over the winter and then "
                "replace, not a bed that lives for years. Plant in October or early November, pick from "
                "late fall into spring, then pull the plants out when summer arrives and start fresh next "
                "fall. Grow them on raised rows covered with plastic or pine straw so the rain drains and "
                "the berries stay clean."),
        "bloom": "Dec - Feb",
        "harvest_start": "Dec",
        "harvest_end": "May",
        "harvest": "Dec - May",
        "frn": ("Gulf Coast strawberry plants are hardy to about 17 degrees Fahrenheit, but the flowers "
                "are damaged below 32 degrees Fahrenheit. Whenever a freeze is forecast and there are open "
                "blossoms, cover the bed with a lightweight row-cover cloth and anchor the edges; remove or "
                "vent it once the freeze passes."),
        "sources": ["lsu_agcenter_3363"],
        "anc": anc("lsu_agcenter_3363"),
    },
    "9": {
        "plant_out": "early Oct - mid Nov",
        "resolution_method": "absolute_month_lsu_planting_dates",
        "gas": ("In the warmer Gulf Coast zone 9, strawberries are grown on the same fall-planted annual "
                "system: set transplants from early October through mid November, with production starting "
                "as early as late November from plugs and running through spring into early summer, then "
                "remove the planting before the humid summer and replant the next fall. Raised rows with "
                "plastic or pine-straw mulch handle the heavy rain and keep fruit clean."),
        "gab": ("In the warmer Gulf Coast areas, strawberries are still a winter crop you grow and then "
                "replace. Plant in October or early November, start picking as early as late fall, keep "
                "going through spring, then pull the plants before the humid summer and replant next fall. "
                "Use raised rows with plastic or pine straw for drainage."),
        "bloom": "Nov - Feb",
        "harvest_start": "Nov",
        "harvest_end": "May",
        "harvest": "Nov - May",
        "frn": ("Zone 9 on the Gulf Coast sees occasional freezes; the plants are hardy to about 17 "
                "degrees Fahrenheit but the open flowers are damaged below 32 degrees Fahrenheit. Cover the "
                "bed with row-cover cloth when a freeze is forecast during bloom and anchor the edges."),
        "sources": ["lsu_agcenter_3363"],
        "anc": anc("lsu_agcenter_3363"),
    },
}

annual_region(
    "se_gulf", "se_gulf", "Southeast & Gulf Coast", ["8", "9"], ["lsu_agcenter_3363"],
    arm_plant={"label": "establishment", "from": None, "window": "early Oct - mid Nov",
               "synthesis_note": gulf_plant_synth, "sources": ["lsu_agcenter_3363"],
               "anchoring_urls": anc("lsu_agcenter_3363")},
    arm_bloom={"label": "establishment", "from": None, "window": "Nov - Feb",
               "synthesis_note": gulf_bloom_synth, "sources": ["lsu_agcenter_3363"],
               "anchoring_urls": anc("lsu_agcenter_3363")},
    arm_hstart={"label": "establishment", "from": None, "window": "Nov - Dec",
                "synthesis_note": gulf_hstart_synth, "sources": ["lsu_agcenter_3363"],
                "anchoring_urls": anc("lsu_agcenter_3363")},
    arm_hend={"label": "establishment", "from": None, "window": "May - early Jun",
              "synthesis_note": gulf_hend_synth, "sources": ["lsu_agcenter_3363"],
              "anchoring_urls": anc("lsu_agcenter_3363")},
    provenance=("Region-constant fall-plant PULLED ANNUAL establishment window, month-resolved (absolute), "
                "NOT frost-relative. The Gulf Coast grows strawberries as a fall-planted annual (LSU "
                "AgCenter Pub 3363/3364, Strawberries): bare-root or plug transplants set early October "
                "through mid November, production from late November (plugs) through the beginning of June, "
                "then the planting is REMOVED in early summer ('disease pressure is extreme in the summer "
                "months') and replaced the following fall. LSU is explicit that the home-garden default is "
                "annual: 'If space is unlimited... strawberries can be continued as perennials. If space is "
                "limited, as it usually is, remove the plants in early summer and plant again the next "
                "fall.' Short-day flower initiation in cool fall/winter; plants hardy to ~17F but flowers "
                "die <32F. This is the humid-Gulf fall-plant PULLED sub-shape (season_over emerges for the "
                "summer off-season). resolved_from null per cell, forced by the cool-fall-initiation, "
                "season-driven window (z8/z9 carry frost, but the limiter is the season + humid-summer "
                "disease, not the last spring frost; the frost dates inform the frost_risk_note only). "
                "Windows anchor to LSU AgCenter Pub 3363/3364. NOTE for Claude Code: calendar[] left [] for "
                "the deriver; this cell is expected to emit season_over (summer off-season). A5: SINGLE "
                "fall-plant window (no separate spring arm); do NOT template the desert, coastal, or "
                "interior windows onto the Gulf cell, and do NOT lift the FL peninsula months -- the Gulf "
                "window is its own (slightly later plant, earlier finish than peninsular FL)."),
    region_notes_seasoned=(
        "On the Southeast and Gulf Coast (zones 8 and 9), strawberries are grown as a fall-planted annual, "
        "not a perennial bed. Set bare-root or plug transplants from early October through mid November "
        "(mid to late October is ideal in southeast Louisiana), on raised rows covered with plastic mulch "
        "or a thick layer of pine straw for drainage and clean fruit. Short-day varieties initiate flowers "
        "in the cool, short days of fall and winter; expect fruit from late fall (as early as late November "
        "from plugs) through winter and spring, running to about early June. After June the plants stop "
        "fruiting and the planting is removed, because humid-summer disease pressure is extreme; replant "
        "fresh each fall. The plants are cold-hardy to roughly 17 degrees Fahrenheit, but open flowers are "
        "damaged below 32, so cover the bed with row-cover cloth on forecast freezes during bloom. Side-"
        "dress with nitrogen in January and again in mid-to-late spring, and rotate away from recent "
        "tomato, pepper, or eggplant beds."),
    region_notes_beginner=(
        "On the Gulf Coast, strawberries are a cool-season crop you grow over the winter and then replace, "
        "not a bed that lives for years. Plant transplants in October or early November on raised rows "
        "covered with plastic or pine straw so the heavy rain drains and the berries stay clean. You will "
        "pick berries from late fall through spring, into early summer. When summer arrives, pull the "
        "plants out, because the heat and humidity bring disease, and plant fresh ones the next fall. The "
        "plants handle cold well, but the flowers do not, so cover them when a freeze is coming. Feed them "
        "in winter and again in spring."),
    cells=se_gulf_cells,
)

# ============================================================================================
# REGION 7: hawaii_tropical (z11) -- PERENNIAL elevation/niche, NOT year_round (CTAHR; flagged)
# ============================================================================================
# CTAHR Hawaii County: Waimea (Hawaii Island) is a major strawberry production area; Kokua Hawaii
# Foundation: Upcountry Maui + Waimea ideal; commercial farms keep year-round supply by harvesting
# HIGHER in summer and LOWER in winter (elevation move). Kula Country Farms home/U-pick season:
# Feb-Jun. -> NOT year_round at a fixed home plot; cool-elevation niche. grown_as = PERENNIAL is
# the lean (cool, frost-free, no killing summer at elevation) but is the WEAKEST of the 7 calls;
# FLAGGED as the residual open finding for Step 5.
hawaii_plant_synth = (
    "In Hawaii, strawberries are a cool-elevation crop, grown upcountry (the slopes of Haleakala on "
    "Maui around Kula, and Waimea on Hawaii Island) where temperatures are mild, rather than in the "
    "warm lowlands. Set transplants in the cool fall months for the main winter-into-spring crop. At "
    "a fixed upcountry elevation this is a seasonal, cool-month crop, not a year-round lowland one. "
    "This is a month-resolved window in a frost-free zone, not anchored to a last spring frost."
)
hawaii_bloom_synth = (
    "Flowering and fruiting follow the cooler upcountry season, building through winter into spring. "
    "Hawaii's day length varies little across the year (roughly 11 to 13.5 hours), so temperature and "
    "elevation, more than day length, set the practical season at a given site."
)
hawaii_hstart_synth = (
    "At a fixed upcountry site the harvest concentrates in the cool months; on Maui the upcountry "
    "U-pick season runs roughly February through June."
)
hawaii_hend_synth = (
    "Fruiting at a single elevation tapers as the warmer season arrives; the cell harvest window is "
    "scoped to the cool-season spring crop. Commercial Maui farms extend supply year-round only by "
    "moving harvest higher up the mountain in summer and lower in winter, which a home garden at one "
    "site cannot do."
)

hawaii_tropical_cells = {
    "11": {
        "plant_out": "Sep - Nov",
        "resolution_method": "absolute_month_ctahr_upcountry_practice",
        "gas": ("In Hawaii (zone 11), strawberries are a cool-elevation niche crop, not a warm-lowland "
                "year-round one. They are grown upcountry, on the cool slopes of Haleakala (around Kula) "
                "and at Waimea on Hawaii Island, where conditions stay mild. At a fixed upcountry site, "
                "treat the bed as a short-lived perennial: set plants in the cool fall months for a main "
                "crop through winter and spring. Year-round supply exists in Hawaii only because commercial "
                "farms move harvest up and down the mountain with the seasons, which a single home garden "
                "cannot replicate. In the warm lowlands strawberries perform poorly."),
        "gab": ("In Hawaii, strawberries grow best up in the cool higher country, like Kula on Maui, not "
                "down in the warm lowlands. Plant in the cool fall months and you will get berries through "
                "winter and spring. The big farms have berries all year because they move up and down the "
                "mountain with the seasons, but in a home garden at one spot you will get a cool-season "
                "crop, not year-round fruit."),
        "bloom": "Nov - Mar",
        "harvest_start": "Feb",
        "harvest_end": "Jun",
        "harvest": "Feb - Jun",
        "frn": ("Upcountry Hawaii (zone 11) is frost-free, so freeze injury to blossoms is not a concern. "
                "The practical season is set by the mild upcountry temperatures and elevation rather than "
                "by cold; warm spells, not frost, end the crop at a given site."),
        "sources": ["ctahr_hawaii_county"],
        "anc": anc("ctahr_hawaii_county"),
    },
}

perennial_region(
    "hawaii_tropical", "hawaii_tropical", "Hawaii (Upcountry / Tropical)", ["11"], ["ctahr_hawaii_county"],
    arm_plant={"label": "establishment", "from": None, "window": "Sep - Nov",
               "synthesis_note": hawaii_plant_synth, "sources": ["ctahr_hawaii_county"],
               "anchoring_urls": anc("ctahr_hawaii_county")},
    arm_bloom={"label": "establishment", "from": None, "window": "Nov - Mar",
               "synthesis_note": hawaii_bloom_synth, "sources": ["ctahr_hawaii_county"],
               "anchoring_urls": anc("ctahr_hawaii_county")},
    arm_hstart={"label": "establishment", "from": None, "window": "Feb",
                "synthesis_note": hawaii_hstart_synth, "sources": ["ctahr_hawaii_county"],
                "anchoring_urls": anc("ctahr_hawaii_county")},
    arm_hend={"label": "establishment", "from": None, "window": "Jun",
              "synthesis_note": hawaii_hend_synth, "sources": ["ctahr_hawaii_county"],
              "anchoring_urls": anc("ctahr_hawaii_county")},
    provenance=("Region-constant cool-elevation PERENNIAL establishment, month-resolved (absolute) in a "
                "frost-free zone, NOT frost-relative. *** A5 + the onion hawaii lesson: hawaii_tropical is "
                "NOT year_round despite frost-free z11. *** CTAHR (Hawaii County diversified-ag page) "
                "documents Waimea (Hawaii Island) as a major strawberry production area, and CTAHR-aligned "
                "education materials place the crop upcountry (Kula on Maui, Waimea) where it is cool; "
                "commercial Maui farms achieve a year-round SUPPLY only by moving harvest HIGHER in summer "
                "and LOWER in winter (an elevation move a fixed home garden cannot do), and the upcountry "
                "U-pick/home season runs roughly Feb-Jun. So a home-garden cell at one elevation is a "
                "cool-season crop, NOT year_round -- this OVERRIDES the zinnia frost-free->year_round "
                "inference, exactly as onion hawaii did. grown_as: authored PERENNIAL (cool, frost-free, no "
                "killing summer heat or winter at upcountry elevation favor a multi-year bed). *** This is "
                "the WEAKEST of the 7 grown_as calls -- no clean CTAHR HOME-GARDEN lifecycle statement "
                "exists; the perennial read is inferred from the cool-elevation niche + frost-free "
                "conditions. FLAGGED as the residual open finding for Step 5 (blocks_launch:false): confirm "
                "perennial-vs-annual + the window against a dedicated CTAHR strawberry publication if one "
                "can be obtained, or soften to an explicitly informational note. *** resolved_from null "
                "(frost-free). NOTE for Claude Code: calendar[] left [] (perennial cycle, NO season_over); "
                "do NOT set year_round. A5: do NOT import the FL z11 fall-plant pulled-annual shape -- the "
                "Hawaii cell is a cool-elevation perennial, a different lifecycle."),
    region_notes_seasoned=(
        "In Hawaii (zone 11), strawberries are a cool-elevation niche crop, not a warm-lowland year-round "
        "one. They are grown upcountry, on the cool slopes of Haleakala around Kula on Maui and at Waimea "
        "on Hawaii Island, where the climate stays mild; in the warm lowlands they perform poorly. At a "
        "fixed upcountry site, treat the planting as a short-lived perennial: set plants in the cool fall "
        "months for a main crop that builds through winter into spring, with the upcountry season running "
        "roughly February through June. Hawaii's day length barely changes across the year, so temperature "
        "and elevation, not day length, set the practical season at a given site. The year-round Hawaiian "
        "strawberry supply you see at markets comes from commercial farms shifting harvest up and down the "
        "mountain with the seasons, which a single home garden cannot replicate. Grow on well-drained beds; "
        "the zone is frost-free, so cold protection is not needed."),
    region_notes_beginner=(
        "In Hawaii, strawberries grow best up in the cool higher country, like Kula on Maui or Waimea on "
        "the Big Island, not down in the warm lowlands. Plant in the cool fall months and you will pick "
        "berries through winter and spring, roughly February through June. There is no frost to worry "
        "about up there. You may have heard Hawaii has strawberries year-round, but that is because big "
        "farms move up and down the mountain with the seasons. In your own garden at one spot, expect a "
        "cool-season crop, not fruit all year. Grow them where water drains away well."),
    cells=hawaii_tropical_cells,
)

# ============================================================================================
# Emit, gate, apply, verify
# ============================================================================================
def content_sha(obj):
    return hashlib.sha256(json.dumps(obj, separators=(",", ":"), ensure_ascii=False, sort_keys=True).encode()).hexdigest()

# Build the deliverable patch (strip the internal from_guard marker into a comment-free op list;
# we keep from_guard separately for our own apply+verify, and emit BOTH: the clean RFC-6901 ops
# for Claude Code, plus the guard metadata as a sidecar the apply script checks).
clean_ops = [{"op": o["op"], "path": o["path"], "value": o["value"]} for o in ops]
guards = [{"path": o["path"], "expect": o["from_guard"]} for o in ops]

# --- self-apply under guard, against a copy ---
slice_obj = json.load(open(SLICE))
work = copy.deepcopy(slice_obj)

def get_pointer(doc, path):
    cur = doc
    for tok in path.split("/")[1:]:
        tok = tok.replace("~1", "/").replace("~0", "~")
        if isinstance(cur, list):
            cur = cur[int(tok)]
        else:
            cur = cur[tok]
    return cur

def set_pointer(doc, path, value):
    toks = path.split("/")[1:]
    cur = doc
    for tok in toks[:-1]:
        tok = tok.replace("~1", "/").replace("~0", "~")
        if isinstance(cur, list):
            cur = cur[int(tok)]
        else:
            cur = cur[tok]
    last = toks[-1].replace("~1", "/").replace("~0", "~")
    if isinstance(cur, list):
        cur[int(last)] = value
    else:
        cur[last] = value

# guard check
guard_failures = []
for g in guards:
    actual = get_pointer(work, g["path"])
    if actual != g["expect"]:
        guard_failures.append((g["path"], g["expect"], actual))
if guard_failures:
    print("GUARD FAILURES:", file=sys.stderr)
    for f in guard_failures[:20]:
        print("  ", f, file=sys.stderr)
    sys.exit(1)

# apply
for o in clean_ops:
    set_pointer(work, o["path"], o["value"])

# write outputs
with open("/home/claude/strawberry-step4/strawberry_step4_patch.json", "w") as f:
    json.dump({"description": "strawberry Step 4 SCALE-UP -- final 7 warm regions (11 cells); calendar[] left [] for deriver",
               "base_note": "apply against canonical crops_data_final.json strawberry crop; ops are RFC-6901 over the strawberry /regions subtree",
               "ops": clean_ops, "from_guards": guards}, f, indent=1, ensure_ascii=False)

with open("/home/claude/strawberry-step4/strawberry_slice_AFTER.json", "w") as f:
    json.dump(work, f, separators=(",", ":"), ensure_ascii=False)

print("OPS:", len(clean_ops))
print("crop SHA BEFORE:", content_sha(slice_obj))
print("crop SHA AFTER :", content_sha(work))

# verification summary
r = work["regions"]
print("\n--- per-region verification ---")
for name in ["low_desert_az","ca_desert","warm_arid","ca_north_coast","ca_south_coast","se_gulf","hawaii_tropical"]:
    cell = r[name]
    zs = sorted(cell["resolved_by_zone"].keys(), key=int)
    gas = {z: cell["resolved_by_zone"][z]["grown_as"] for z in zs}
    track = cell["plantings"][0]["track"]
    rfroms = {z: ("populated" if cell["resolved_by_zone"][z]["resolved_from"] else "null") for z in zs}
    cals = {z: cell["resolved_by_zone"][z]["calendar"] for z in zs}
    allcalsempty = all(len(c)==0 for c in cals.values())
    print(f"{name}: track={track} grown_as={gas} resolved_from={rfroms} calendar_empty={allcalsempty}")

# collateral: confirm the 3 already-filled regions are byte-identical
print("\n--- collateral (already-filled regions unchanged) ---")
for name in ["northern_tier","ca_interior","fl_peninsula"]:
    same = json.dumps(slice_obj["regions"][name], sort_keys=True) == json.dumps(work["regions"][name], sort_keys=True)
    print(f"{name}: unchanged={same}")
# confirm no other top-level crop keys changed
otherkeys_same = all(
    json.dumps(slice_obj[k], sort_keys=True) == json.dumps(work[k], sort_keys=True)
    for k in slice_obj if k != "regions"
)
print("non-regions crop keys unchanged:", otherkeys_same)
