# strawberry Step 4 SCALE-UP -- RELEASE kickoff (Claude Code lane)

**This completes region fill 10/10.** The author lane (claude.ai) has filled the LAST 7 warm regions (11 cells). Your job: apply, derive, reconcile, mint, gate, promote.

**Start SHA (canonical, gate on it):** `78ebccffe5a50293799ec5fd5f3c1f44492076dc8640d9117e89da5167476255` (`strawberry_step4_fl_peninsula`)
**Patch:** `strawberry_step4_patch.json` -- 225 ops + 225 from_guards, RFC-6901 over the strawberry `/regions` subtree. `calendar[]` left `[]` on all 11 cells.
**Author-lane crop SHA (slice, BEFORE):** `210f42ea606288a0bf96895272ccb9b429950c853d188d0af7e9f71aa8a64fde`
**Author-lane crop SHA (slice, AFTER, pre-derive/pre-mint):** `f1c8ad95a07a862c14eb86c91130b4e1808fdee71812a5aed5284fe37bf3357f`
> The AFTER SHA is the author-lane slice with `calendar[]` still empty and citations on the new page sub-IDs as authored. It will NOT survive the deriver + mint unchanged -- it is a structural cross-check for the apply step only, not a post-release target. Re-pin the real end SHA after derive+mint+reconcile, exactly as the fl_peninsula round did.

## The 11 cells filled (each grown_as + window = an independent SOURCE finding, A5)
| Region | Zones | grown_as | Shape | resolved_from |
|---|---|---|---|---|
| low_desert_az | 9 | annual | desert fall-plant PULLED | null |
| ca_desert | 9, 10 | annual | desert fall-plant PULLED | null |
| warm_arid | 8 | **perennial** | spring-plant matted row | **populated** (frost-anchored) |
| ca_north_coast | 9, 10 | annual | coastal fall-plant winter-production | null |
| ca_south_coast | 9, 10 | annual | coastal fall-plant winter-production | null |
| se_gulf | 8, 9 | annual | Gulf fall-plant PULLED | null |
| hawaii_tropical | 11 | **perennial** (NOT year_round) | cool-elevation niche | null (frost-free) |

Full sourcing, the two surfaced decisions (A: warm_arid perennial overturn; B: hawaii weakest call), and per-region windows are in `strawberry_step4_scaleup_findings.md` (in `1_for_project_knowledge/` and `3_for_your_records/`).

## Release steps (in order)
1. **Preflight:** `sha256(crops_data_final.json)` == `78ebccff...`. Apply the 225 from-guarded ops against canonical under the SHA gate (`sys.exit(1)` on any guard mismatch). Collateral: only the strawberry crop changes; the 3 filled proof cells (northern_tier / ca_interior / fl_peninsula) and all non-`regions` keys stay byte-identical.

2. **Mint 5 new page sub-IDs** under their trusted parents (all T1 by inheritance, `_admission_provenance` recorded; mirror `uf_ifas_hs403`):
   - `uariz_ext_az1667` (parent `uariz_ext`) -- UA Coop Ext AZ1667 -- low_desert_az, ca_desert
   - `nmsu_ext_h324` (parent `nmsu_ext`) -- NMSU Guide H-324 -- warm_arid
   - `ucanr_mg_monterey_santacruz` (parent `uc_anr`) -- UC MG Monterey & Santa Cruz -- ca_north_coast, ca_south_coast
   - `lsu_agcenter_3363` (parent `lsu_agcenter`) -- LSU AgCenter Pub 3363/3364 -- se_gulf
   - `ctahr_hawaii_county` (parent `ctahr`) -- UH CTAHR Hawaii County -- hawaii_tropical
   - Reused (already catalogued): `uc_ipm` (coastal cell harvest anchor -- "heaviest production May-June," the ca_interior anchor).
   - URLs are in the patch's `anchoring_urls` leaves and the findings doc (all verified 2026-06-18). The author lane cited the new sub-IDs directly in `sources`/`anchoring_urls`, so NO re-point is needed this round (unlike fl_peninsula, which had cited bare `uf_ifas`) -- but confirm the source-tier gate sees them as catalogued after the mint (0 uncatalogued, 0 non-T1).

3. **Derive `calendar[]` per cell** (`derive_berry_calendars` or equivalent):
   - **season_over EMERGES** for the 5 pulled-annual cells: low_desert_az z9, ca_desert z9/z10, se_gulf z8/z9 (clean summer no-plant gap).
   - **NO season_over** for the 2 perennial cells: warm_arid z8 (dormant + bloom + harvest + renovation, frost-relative) and hawaii_tropical z11 (dormant cycle, frost-free).
   - **VERIFY the deriver branch on the 4 coastal annual cells** (ca_north_coast z9/z10, ca_south_coast z9/z10): the mild-coast fall-to-summer windows WRAP without a clean summer gap, so the deriver may correctly NOT emit season_over (carried-vs-pulled is emergent from whether windows wrap or leave a gap -- the ca_interior-vs-fl_peninsula precedent). Confirm it does the right thing rather than forcing a token.

4. **Frost reconcile (the onion NT lesson):** warm_arid z8 is the ONLY frost-anchored new cell. Reconcile its `resolved_from` (author wrote last_frost Feb 15 / first_frost Dec 1) against live `zone_frost_data` z8 and re-derive the offset-based dates. The author's `plant_out` (Mar 1 - Mar 22, from `from: last_frost` / `offset_days: -14` / `window_days: 21`) is illustrative; the deriver is authoritative.

5. **Pre-existing ORPHAN null region-root keys (decide disposition + gate explicitly):** these 3 null keys are NOT in the filled reference cells and were left UNTOUCHED (author lane does not delete structure) -- same class as the onion z11 `season_bound` key that HALTed `register_completeness_gate`:
   - `ca_desert.zone_10_desert_fold` = null
   - `ca_north_coast.zone_8_presence` = null
   - `ca_south_coast.zone_8_presence` = null
   Decide disposition (drop or rule) and **run `register_completeness_gate` EXPLICITLY** -- `whole_crop_gate` B + `release_verify` do not catch a novel unruled null/prose key; the CURRENT_STATE regen is the backstop.

6. **Gates:**
   ```
   python3 tools/whole_crop_gate.py strawberry          # A2 region-fill -> 0; A10; A11 (post-deriver)
   python3 tools/register_completeness_gate.py crops_data_final.json
   ```
   Expected: `whole_crop_gate` region-fill gaps **-> 0** (this completes 10/10); A10 = 0, A11 = 0 post-derive. `register_completeness` PASS once the 3 orphan keys are dispositioned.

7. **Re-pin + commit:** compute the real end SHA, refresh `LATEST.txt` (new session label, e.g. `strawberry_step4_scaleup`), regenerate `CURRENT_STATE.md` in full (both locations), **append the `STATE_HISTORY_snippet.md` entry to the top of the chronological stack** in `STATE_HISTORY.md` (most-recent-first, beneath the header + its `---`; do NOT delta-edit), commit.

## After release -> region fill 10/10. THEN:
**Step 5** (whole-crop verification): source-fidelity re-fetch of every cited window/number; the **once-global `hardiness_zone` / `reliable_fruit_zone` boundary-scalar decision** (Trevor's call, Option-1 lean -- leave the scalars as perennial-survival / reliable-perennial semantics; the `grown_as: annual` z9-11 cells carry the annual reality); the chill figure; and **resolve the hawaii grown_as open finding** (Decision B). -> **Steps 6-8** (bulk prose incl. the deferred day-neutral `type_selection_*` story + the ca_interior small fall crop) -> **Step 9** -> **Step 11 cert + the four-flip close.** The arc is NOT done; the region-cell SLICE is.
